// api/auth/index.ts
import { serve } from "bun";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";

const JWT_SECRET = process.env.JWT_SECRET || "super-secret-key";

// temporary user list in memory (we’ll make it persistent later)
const users: any[] = [];

// utility for JSON responses
function jsonResponse(data: any, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
    },
  });
}

serve({
  async fetch(req) {
    const url = new URL(req.url);
    const path = url.pathname;
    const method = req.method;

    console.log("Incoming request:", path, method);

    // ✅ handle preflight CORS
    if (method === "OPTIONS") {
      return new Response(null, {
        status: 200,
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
          "Access-Control-Allow-Headers": "Content-Type, Authorization",
        },
      });
    }

    // ✅ SIGNUP
    if (path === "/api/auth/signup" && method === "POST") {
      try {
        const { email, username, password } = await req.json();
        if (!email || !username || !password)
          return jsonResponse({ error: "Missing fields" }, 400);

        const exists = users.find((u) => u.email === email);
        if (exists) return jsonResponse({ error: "User already exists" }, 400);

        const hashed = await bcrypt.hash(password, 10);
        const user = { id: crypto.randomUUID(), email, username, password: hashed };
        users.push(user);

        const token = jwt.sign({ id: user.id, email }, JWT_SECRET, { expiresIn: "7d" });

        return jsonResponse({ user: { id: user.id, email, username }, token });
      } catch (err) {
        console.error("Signup error:", err);
        return jsonResponse({ error: "Signup failed" }, 500);
      }
    }

    // ✅ LOGIN
    if (path === "/api/auth/login" && method === "POST") {
      try {
        const { email, password } = await req.json();
        if (!email || !password)
          return jsonResponse({ error: "Missing email or password" }, 400);

        const user = users.find((u) => u.email === email);
        if (!user) return jsonResponse({ error: "Invalid credentials" }, 401);

        const valid = await bcrypt.compare(password, user.password);
        if (!valid) return jsonResponse({ error: "Invalid credentials" }, 401);

        const token = jwt.sign({ id: user.id, email }, JWT_SECRET, { expiresIn: "7d" });
        return jsonResponse({ user: { id: user.id, email, username: user.username }, token });
      } catch (err) {
        console.error("Login error:", err);
        return jsonResponse({ error: "Login failed" }, 500);
      }
    }

    // ✅ Protected route
    if (path === "/api/auth/me" && method === "GET") {
      try {
        const auth = req.headers.get("Authorization");
        if (!auth || !auth.startsWith("Bearer "))
          return jsonResponse({ error: "Unauthorized" }, 401);

        const token = auth.split(" ")[1];
        const decoded = jwt.verify(token, JWT_SECRET) as any;
        const user = users.find((u) => u.id === decoded.id);
        if (!user) return jsonResponse({ error: "User not found" }, 404);

        return jsonResponse({ user: { id: user.id, email: user.email, username: user.username } });
      } catch {
        return jsonResponse({ error: "Invalid token" }, 401);
      }
    }

    // fallback
    return jsonResponse({ error: "Not found" }, 404);
  },
});
