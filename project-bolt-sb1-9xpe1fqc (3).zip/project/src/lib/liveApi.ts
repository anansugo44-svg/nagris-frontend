import type { User } from '../lib/types';

export interface LiveStream {
  id: string;
  user_id: string;
  title: string;
  description: string;
  thumbnail_url: string;
  is_active: boolean;
  viewer_count: number;
  total_likes: number;
  total_gifts_received: number;
  total_gift_value: number;
  agora_channel_id?: string;
  agora_token?: string;
  started_at: string;
  ended_at?: string;
  user?: {
    id: string;
    username: string;
    avatar_url: string;
    is_verified: boolean;
  };
}

export interface LiveGame {
  id: string;
  live_room_id: string;
  game_type: 'poll' | 'trivia' | 'spin_wheel';
  game_data: any;
  results?: any;
  is_active: boolean;
  created_at: string;
}

export interface ChatMessage {
  id: string;
  live_room_id: string;
  user_id: string;
  message: string;
  created_at: string;
  user?: {
    username: string;
    avatar_url: string;
    is_verified: boolean;
  };
}

export interface GiftTransaction {
  id: string;
  live_stream_id: string;
  gift_id: string;
  sender_id: string;
  recipient_id: string;
  coin_amount: number;
  creator_share: number;
  platform_share: number;
  created_at: string;
}

export const liveApi = {
  async canStartLive(): Promise<{ canStart: boolean; followerCount: number }> {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('Not authenticated');

    const { data: profile } = await supabase
      .from('users')
      .select('followers_count')
      .eq('id', user.id)
      .maybeSingle();

    const followerCount = profile?.followers_count || 0;
    return {
      canStart: followerCount >= 500,
      followerCount,
    };
  },

  async startLive(title: string, description: string, thumbnail_url?: string): Promise<LiveStream> {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('Not authenticated');

    const { canStart, followerCount } = await this.canStartLive();
    if (!canStart) {
      throw new Error(`You need at least 500 followers to start a live stream. Current: ${followerCount}`);
    }

    const agoraChannelId = `live_${user.id}_${Date.now()}`;

    const { data, error } = await supabase
      .from('live_streams')
      .insert({
        user_id: user.id,
        title,
        description,
        thumbnail_url: thumbnail_url || '',
        is_active: true,
        viewer_count: 0,
        total_likes: 0,
        total_gifts_received: 0,
        total_gift_value: 0,
        agora_channel_id: agoraChannelId,
        started_at: new Date().toISOString(),
      })
      .select()
      .single();

    if (error) throw error;

    await this.joinLive(data.id);

    return data;
  },

  async endLive(liveStreamId: string): Promise<void> {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('Not authenticated');

    const { error } = await supabase
      .from('live_streams')
      .update({
        is_active: false,
        ended_at: new Date().toISOString(),
      })
      .eq('id', liveStreamId)
      .eq('user_id', user.id);

    if (error) throw error;

    await supabase
      .from('live_viewers')
      .update({ left_at: new Date().toISOString() })
      .eq('live_stream_id', liveStreamId)
      .is('left_at', null);
  },

  async getActiveLiveStreams(): Promise<LiveStream[]> {
    const { data, error } = await supabase
      .from('live_streams')
      .select(`
        *,
        user:users(id, username, avatar_url, is_verified)
      `)
      .eq('is_active', true)
      .order('started_at', { ascending: false });

    if (error) throw error;
    return data || [];
  },

  async getLiveStream(id: string): Promise<LiveStream | null> {
    const { data, error } = await supabase
      .from('live_streams')
      .select(`
        *,
        user:users(id, username, avatar_url, is_verified)
      `)
      .eq('id', id)
      .maybeSingle();

    if (error) throw error;
    return data;
  },

  async joinLive(liveStreamId: string): Promise<void> {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('Not authenticated');

    const { error } = await supabase
      .from('live_viewers')
      .upsert({
        live_stream_id: liveStreamId,
        user_id: user.id,
        joined_at: new Date().toISOString(),
        left_at: null,
      }, {
        onConflict: 'live_stream_id,user_id'
      });

    if (error) throw error;

    await supabase.rpc('increment', {
      table_name: 'live_streams',
      row_id: liveStreamId,
      column_name: 'viewer_count',
    });
  },

  async leaveLive(liveStreamId: string): Promise<void> {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('Not authenticated');

    await supabase
      .from('live_viewers')
      .update({ left_at: new Date().toISOString() })
      .eq('live_stream_id', liveStreamId)
      .eq('user_id', user.id);

    const { data: stream } = await supabase
      .from('live_streams')
      .select('viewer_count')
      .eq('id', liveStreamId)
      .single();

    if (stream && stream.viewer_count > 0) {
      await supabase
        .from('live_streams')
        .update({ viewer_count: stream.viewer_count - 1 })
        .eq('id', liveStreamId);
    }
  },

  async sendChatMessage(liveRoomId: string, message: string): Promise<void> {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('Not authenticated');

    const { error } = await supabase
      .from('live_chat')
      .insert({
        live_room_id: liveRoomId,
        user_id: user.id,
        message,
      });

    if (error) throw error;
  },

  async getChatMessages(liveRoomId: string, limit = 50): Promise<ChatMessage[]> {
    const { data, error } = await supabase
      .from('live_chat')
      .select(`
        *,
        user:users(username, avatar_url, is_verified)
      `)
      .eq('live_room_id', liveRoomId)
      .order('created_at', { ascending: false })
      .limit(limit);

    if (error) throw error;
    return (data || []).reverse();
  },

  async sendGift(liveStreamId: string, giftId: string): Promise<void> {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('Not authenticated');

    const { data: gift } = await supabase
      .from('gifts')
      .select('coin_cost')
      .eq('id', giftId)
      .single();

    if (!gift) throw new Error('Gift not found');

    const { data: wallet } = await supabase
      .from('wallets')
      .select('coin_balance')
      .eq('user_id', user.id)
      .single();

    if (!wallet || wallet.coin_balance < gift.coin_cost) {
      throw new Error('Insufficient coins');
    }

    const { data: stream } = await supabase
      .from('live_streams')
      .select('user_id')
      .eq('id', liveStreamId)
      .single();

    if (!stream) throw new Error('Live stream not found');

    const creatorShare = Math.floor(gift.coin_cost * 0.4);
    const platformShare = gift.coin_cost - creatorShare;

    await supabase
      .from('wallets')
      .update({ coin_balance: wallet.coin_balance - gift.coin_cost })
      .eq('user_id', user.id);

    const { data: recipientWallet } = await supabase
      .from('wallets')
      .select('gift_balance')
      .eq('user_id', stream.user_id)
      .single();

    await supabase
      .from('wallets')
      .update({
        gift_balance: (recipientWallet?.gift_balance || 0) + creatorShare
      })
      .eq('user_id', stream.user_id);

    await supabase
      .from('live_gift_transactions')
      .insert({
        live_stream_id: liveStreamId,
        gift_id: giftId,
        sender_id: user.id,
        recipient_id: stream.user_id,
        coin_amount: gift.coin_cost,
        creator_share: creatorShare,
        platform_share: platformShare,
      });

    await supabase
      .from('live_streams')
      .update({
        total_gifts_received: (await supabase
          .from('live_streams')
          .select('total_gifts_received')
          .eq('id', liveStreamId)
          .single()).data.total_gifts_received + 1
      })
      .eq('id', liveStreamId);
  },

  async startGame(liveRoomId: string, gameType: 'poll' | 'trivia' | 'spin_wheel', gameData: any): Promise<LiveGame> {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('Not authenticated');

    const { data, error } = await supabase
      .from('live_games')
      .insert({
        live_room_id: liveRoomId,
        game_type: gameType,
        game_data: gameData,
        is_active: true,
      })
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async endGame(gameId: string): Promise<void> {
    const { error } = await supabase
      .from('live_games')
      .update({ is_active: false })
      .eq('id', gameId);

    if (error) throw error;
  },

  async submitGameAnswer(gameId: string, answer: any): Promise<void> {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('Not authenticated');

    const { data: game } = await supabase
      .from('live_games')
      .select('*')
      .eq('id', gameId)
      .single();

    if (!game) throw new Error('Game not found');

    let isCorrect = false;
    if (game.game_type === 'trivia' && game.game_data.correctAnswer) {
      isCorrect = answer === game.game_data.correctAnswer;
    }

    const { error } = await supabase
      .from('live_game_responses')
      .upsert({
        game_id: gameId,
        user_id: user.id,
        answer,
        is_correct: isCorrect,
      }, {
        onConflict: 'game_id,user_id'
      });

    if (error) throw error;
  },

  async getGameResults(gameId: string): Promise<any> {
    const { data, error } = await supabase
      .from('live_game_responses')
      .select('answer, is_correct, user:users(username, avatar_url)')
      .eq('game_id', gameId);

    if (error) throw error;

    const results: Record<string, number> = {};
    (data || []).forEach((response: any) => {
      const answerKey = JSON.stringify(response.answer);
      results[answerKey] = (results[answerKey] || 0) + 1;
    });

    return {
      responses: data,
      summary: results,
      totalResponses: data?.length || 0,
    };
  },

  subscribeToChatMessages(liveRoomId: string, callback: (message: ChatMessage) => void) {
    return supabase
      .channel(`live_chat:${liveRoomId}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'live_chat',
          filter: `live_room_id=eq.${liveRoomId}`,
        },
        async (payload) => {
          const { data: user } = await supabase
            .from('users')
            .select('username, avatar_url, is_verified')
            .eq('id', payload.new.user_id)
            .single();

          callback({
            ...payload.new,
            user,
          } as ChatMessage);
        }
      )
      .subscribe();
  },

  subscribeToGifts(liveStreamId: string, callback: (gift: any) => void) {
    return supabase
      .channel(`gifts:${liveStreamId}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'live_gift_transactions',
          filter: `live_stream_id=eq.${liveStreamId}`,
        },
        (payload) => {
          callback(payload.new);
        }
      )
      .subscribe();
  },

  subscribeToGames(liveRoomId: string, callback: (game: LiveGame) => void) {
    return supabase
      .channel(`games:${liveRoomId}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'live_games',
          filter: `live_room_id=eq.${liveRoomId}`,
        },
        (payload) => {
          callback(payload.new as LiveGame);
        }
      )
      .subscribe();
  },
};
