import type { User } from '../lib/types';

export interface VerificationResult {
  success: boolean;
  countryCode?: string;
  vpnDetected?: boolean;
  message?: string;
}

export interface CountryInfo {
  code: string;
  name: string;
  eligibleForViewPayouts: boolean;
}

export const ELIGIBLE_COUNTRIES = ['KE', 'SO'];

export const COUNTRY_NAMES: Record<string, string> = {
  'KE': 'Kenya',
  'SO': 'Somalia'
};

export async function detectCountry(): Promise<{ countryCode: string; vpnDetected: boolean }> {
  try {
    const response = await fetch('https://ipapi.co/json/');
    const data = await response.json();

    const countryCode = data.country_code || 'UNKNOWN';
    const vpnDetected = data.vpn || data.proxy || data.hosting || false;

    return { countryCode, vpnDetected };
  } catch (error) {
    console.error('Error detecting country:', error);
    return { countryCode: 'UNKNOWN', vpnDetected: false };
  }
}

export async function generateVerificationCode(): Promise<string> {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

export async function sendVerificationCode(userId: string, code: string): Promise<boolean> {
  try {
    const expiresAt = new Date();
    expiresAt.setMinutes(expiresAt.getMinutes() + 15);

    const { countryCode, vpnDetected } = await detectCountry();

    const { error } = await supabase
      .from('user_verification')
      .upsert({
        user_id: userId,
        country_code: countryCode,
        verification_code: code,
        code_expires_at: expiresAt.toISOString(),
        vpn_detected: vpnDetected,
        is_verified: false
      });

    if (error) throw error;

    console.log(`Verification code for user ${userId}: ${code}`);

    return true;
  } catch (error) {
    console.error('Error sending verification code:', error);
    return false;
  }
}

export async function verifyCode(userId: string, code: string): Promise<VerificationResult> {
  try {
    const { data, error } = await supabase
      .from('user_verification')
      .select('*')
      .eq('user_id', userId)
      .maybeSingle();

    if (error) throw error;
    if (!data) {
      return { success: false, message: 'No verification request found' };
    }

    if (data.verification_code !== code) {
      return { success: false, message: 'Invalid verification code' };
    }

    const expiresAt = new Date(data.code_expires_at);
    if (expiresAt < new Date()) {
      return { success: false, message: 'Verification code expired' };
    }

    if (data.vpn_detected) {
      return {
        success: false,
        message: 'VPN detected. Please disable VPN and try again.',
        vpnDetected: true
      };
    }

    const { error: updateError } = await supabase
      .from('user_verification')
      .update({
        is_verified: true,
        verified_at: new Date().toISOString()
      })
      .eq('user_id', userId);

    if (updateError) throw updateError;

    await supabase.rpc('calculate_monetization_eligibility', { p_user_id: userId });

    return {
      success: true,
      countryCode: data.country_code,
      vpnDetected: false
    };
  } catch (error) {
    console.error('Error verifying code:', error);
    return { success: false, message: 'Verification failed' };
  }
}

export async function getUserVerification(userId: string) {
  const { data, error } = await supabase
    .from('user_verification')
    .select('*')
    .eq('user_id', userId)
    .maybeSingle();

  if (error) {
    console.error('Error fetching verification:', error);
    return null;
  }

  return data;
}

export async function getMonetizationEligibility(userId: string) {
  const { data, error } = await supabase
    .from('monetization_eligibility')
    .select('*')
    .eq('user_id', userId)
    .maybeSingle();

  if (error) {
    console.error('Error fetching eligibility:', error);
    return null;
  }

  return data;
}

export function isEligibleCountry(countryCode: string): boolean {
  return ELIGIBLE_COUNTRIES.includes(countryCode);
}

export function getCountryName(countryCode: string): string {
  return COUNTRY_NAMES[countryCode] || countryCode;
}

export async function refreshMonetizationStatus(userId: string): Promise<void> {
  try {
    await supabase.rpc('calculate_monetization_eligibility', { p_user_id: userId });
  } catch (error) {
    console.error('Error refreshing monetization status:', error);
  }
}