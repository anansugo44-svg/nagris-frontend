// api.ts
import { apiRequest } from "./apiRequest";
import type {
  Video,
  User,
  Comment,
  Notification,
  Wallet,
  WithdrawalRequest,
  LiveRoom,
  Music,
} from "./types";

// helper for auth headers
function getAuthHeaders() {
  const token = localStorage.getItem("token");
  return {
    Authorization: token ? `Bearer ${token}` : "",
    "Content-Type": "application/json",
  };
}

export const api = {
  // ===== Videos =====
  async getVideos(cursor?: string, limit = 10): Promise<{ videos: Video[]; nextCursor?: string }> {
    const data = await apiRequest("GET", `/videos?limit=${limit}${cursor ? `&cursor=${cursor}` : ""}`, null, getAuthHeaders());
    return {
      videos: data.videos || [],
      nextCursor: data.nextCursor,
    };
  },

  async uploadVideo(video: { title: string; url: string; is_private?: boolean }) {
    const data = await apiRequest("POST", "/videos", video, getAuthHeaders());
    return data;
  },

  async getFollowingVideos(cursor?: string, limit = 10): Promise<{ videos: Video[]; nextCursor?: string }> {
    const data = await apiRequest("GET", `/videos/following?limit=${limit}${cursor ? `&cursor=${cursor}` : ""}`, null, getAuthHeaders());
    return {
      videos: data.videos || [],
      nextCursor: data.nextCursor,
    };
  },

  async getVideoById(id: string): Promise<Video | null> {
    return await apiRequest("GET", `/videos/${id}`, null, getAuthHeaders());
  },

  // ===== Users =====
  async getUserProfile(userId: string): Promise<User | null> {
    return await apiRequest("GET", `/users/${userId}`, null, getAuthHeaders());
  },

  async getUserVideos(userId: string, tab: "videos" | "liked" | "private" | "saved" = "videos"): Promise<Video[]> {
    return await apiRequest("GET", `/users/${userId}/videos?tab=${tab}`, null, getAuthHeaders());
  },

  // ===== Likes & Saves =====
  async likeVideo(videoId: string): Promise<void> {
    await apiRequest("POST", `/videos/${videoId}/like`, null, getAuthHeaders());
  },

  async unlikeVideo(videoId: string): Promise<void> {
    await apiRequest("DELETE", `/videos/${videoId}/like`, null, getAuthHeaders());
  },

  async checkVideoLiked(videoId: string): Promise<boolean> {
    const data = await apiRequest("GET", `/videos/${videoId}/liked`, null, getAuthHeaders());
    return data.liked;
  },

  async saveVideo(videoId: string): Promise<void> {
    await apiRequest("POST", `/videos/${videoId}/save`, null, getAuthHeaders());
  },

  async unsaveVideo(videoId: string): Promise<void> {
    await apiRequest("DELETE", `/videos/${videoId}/save`, null, getAuthHeaders());
  },

  async checkVideoSaved(videoId: string): Promise<boolean> {
    const data = await apiRequest("GET", `/videos/${videoId}/saved`, null, getAuthHeaders());
    return data.saved;
  },

  // ===== Comments =====
  async getComments(videoId: string): Promise<Comment[]> {
    const data = await apiRequest("GET", `/videos/${videoId}/comments`, null, getAuthHeaders());
    return data || [];
  },

  async addComment(videoId: string, content: string, parentId?: string): Promise<void> {
    await apiRequest("POST", `/videos/${videoId}/comments`, { content, parentId }, getAuthHeaders());
  },

  async deleteComment(commentId: string): Promise<void> {
    await apiRequest("DELETE", `/comments/${commentId}`, null, getAuthHeaders());
  },

  async likeComment(commentId: string): Promise<void> {
    await apiRequest("POST", `/comments/${commentId}/like`, null, getAuthHeaders());
  },

  async unlikeComment(commentId: string): Promise<void> {
    await apiRequest("DELETE", `/comments/${commentId}/like`, null, getAuthHeaders());
  },

  async checkCommentLiked(commentId: string): Promise<boolean> {
    const data = await apiRequest("GET", `/comments/${commentId}/liked`, null, getAuthHeaders());
    return data.liked;
  },

  async getCommentLikedStates(commentIds: string[]): Promise<Record<string, boolean>> {
    const data = await apiRequest("POST", `/comments/liked-states`, { commentIds }, getAuthHeaders());
    return data || {};
  },

  async pinComment(videoId: string, commentId: string): Promise<void> {
    await apiRequest("POST", `/videos/${videoId}/comments/${commentId}/pin`, null, getAuthHeaders());
  },

  async unpinComment(videoId: string, commentId: string): Promise<void> {
    await apiRequest("DELETE", `/videos/${videoId}/comments/${commentId}/pin`, null, getAuthHeaders());
  },

  // ===== Follows =====
  async followUser(userId: string): Promise<void> {
    await apiRequest("POST", `/users/${userId}/follow`, null, getAuthHeaders());
  },

  async unfollowUser(userId: string): Promise<void> {
    await apiRequest("DELETE", `/users/${userId}/follow`, null, getAuthHeaders());
  },

  async isFollowing(userId: string): Promise<boolean> {
    const data = await apiRequest("GET", `/users/${userId}/following`, null, getAuthHeaders());
    return data.following;
  },

  async getFollowers(userId: string): Promise<User[]> {
    const data = await apiRequest("GET", `/users/${userId}/followers`, null, getAuthHeaders());
    return data || [];
  },

  async getFollowing(userId: string): Promise<User[]> {
    const data = await apiRequest("GET", `/users/${userId}/following-list`, null, getAuthHeaders());
    return data || [];
  },

  async getFollowingIds(): Promise<string[]> {
    const data = await apiRequest("GET", `/users/following-ids`, null, getAuthHeaders());
    return data || [];
  },

  // ===== Search =====
  async search(query: string): Promise<{ users: User[]; videos: Video[] }> {
    return await apiRequest("GET", `/search?q=${encodeURIComponent(query)}`, null, getAuthHeaders());
  },

  // ===== Notifications =====
  async getNotifications(): Promise<Notification[]> {
    return await apiRequest("GET", "/notifications", null, getAuthHeaders());
  },

  async markNotificationRead(notificationId: string): Promise<void> {
    await apiRequest("POST", `/notifications/${notificationId}/read`, null, getAuthHeaders());
  },

  // ===== Wallet / Withdrawals =====
  async getWallet(): Promise<Wallet | null> {
    return await apiRequest("GET", "/wallet", null, getAuthHeaders());
  },

  async getWithdrawalRequests(): Promise<WithdrawalRequest[]> {
    return await apiRequest("GET", "/withdrawals", null, getAuthHeaders());
  },

  async createWithdrawal(amount: number, balanceType: string, paymentMethod: string, paymentDetails: any): Promise<void> {
    await apiRequest("POST", "/withdrawals", { amount, balanceType, paymentMethod, paymentDetails }, getAuthHeaders());
  },

  // ===== Live Rooms / Music =====
  async getLiveRooms(): Promise<LiveRoom[]> {
    return await apiRequest("GET", "/live-rooms", null, getAuthHeaders());
  },

  async getMusicLibrary(): Promise<Music[]> {
    return await apiRequest("GET", "/music", null, getAuthHeaders());
  },

  // ===== Blocking & Reporting =====
  async blockUser(userId: string): Promise<void> {
    await apiRequest("POST", `/users/${userId}/block`, null, getAuthHeaders());
  },

  async unblockUser(userId: string): Promise<void> {
    await apiRequest("DELETE", `/users/${userId}/block`, null, getAuthHeaders());
  },

  async isBlocked(userId: string): Promise<boolean> {
    const data = await apiRequest("GET", `/users/${userId}/blocked`, null, getAuthHeaders());
    return data.blocked;
  },

  async reportContent(type: "user" | "video", id: string, reason: string, description: string): Promise<void> {
    await apiRequest("POST", `/reports`, { type, id, reason, description }, getAuthHeaders());
  },

  // ===== Watch History / Shares =====
  async addWatchHistory(videoId: string): Promise<void> {
    await apiRequest("POST", `/videos/${videoId}/watch`, null, getAuthHeaders());
  },

  async shareVideo(videoId: string): Promise<void> {
    await apiRequest("POST", `/videos/${videoId}/share`, null, getAuthHeaders());
  },
};
