// src/lib/apiRequest.ts
// ✅ FINAL VERSION for Bolt backend integration

// Leave empty string to automatically use the same origin (Bolt internal API)
const API_BASE = ""; 

/**
 * Helper to make API requests with fetch
 * @param method - HTTP method (GET, POST, PUT, DELETE)
 * @param endpoint - API endpoint (e.g. "/auth/login")
 * @param body - Request body (optional)
 * @param headers - Extra headers (optional)
 */
export async function apiRequest(
  method: "GET" | "POST" | "PUT" | "DELETE",
  endpoint: string,
  body: any = null,
  headers: Record<string, string> = {}
) {
  try {
    const res = await fetch(`${API_BASE}${endpoint}`, {
      method,
      headers: {
        "Content-Type": "application/json",
        ...headers,
      },
      body: body ? JSON.stringify(body) : null,
    });

    if (!res.ok) {
      const errorText = await res.text();
      throw new Error(errorText || `Request failed: ${res.status}`);
    }

    return await res.json();
  } catch (err: any) {
    console.error("API Request error:", err);
    throw err;
  }
}
