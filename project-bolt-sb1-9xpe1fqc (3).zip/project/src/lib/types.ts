// types.ts

// ========== USERS ==========
export interface User {
  id: string;
  username: string;
  email: string;
  avatar_url: string;
  bio: string;
  country: string;
  followers_count: number;
  following_count: number;
  total_likes: number;
  total_views: number;
  is_verified: boolean;
  kyc_status: string;
  kyc_documents: any;
  fraud_score: number;
  is_blocked: boolean;
  created_at: string;
}

// ========== VIDEOS ==========
export interface Video {
  id: string;
  user_id: string;
  title: string;
  video_url: string;
  thumbnail_url: string;
  duration: number;
  music_id?: string;
  is_private: boolean;
  views_count: number;
  likes_count: number;
  comments_count: number;
  shares_count: number;
  is_flagged: boolean;
  moderation_status: string;
  created_at: string;
  user?: User;
}

// ========== COMMENTS ==========
export interface Comment {
  id: string;
  video_id: string;
  user_id: string;
  parent_id?: string;
  content: string;
  likes_count: number;
  created_at: string;
  user?: User;
  replies?: Comment[];
}

// ========== SOCIAL ==========
export interface Follow {
  id: string;
  follower_id: string;
  following_id: string;
  created_at: string;
}

export interface Like {
  id: string;
  user_id: string;
  video_id: string;
  created_at: string;
}

export interface Save {
  id: string;
  user_id: string;
  video_id: string;
  created_at: string;
}

export interface WatchHistory {
  id: string;
  user_id: string;
  video_id: string;
  watched_at: string;
}

export interface Block {
  id: string;
  blocker_id: string;
  blocked_id: string;
  created_at: string;
}

// ========== WALLET ==========
export interface Wallet {
  id: string;
  user_id: string;
  views_balance_usd: number;
  gifts_balance_usd: number;
  total_earned_usd: number;
  total_withdrawn_usd: number;
  coins_balance: number;
  is_frozen: boolean;
  updated_at: string;
}

export interface WithdrawalRequest {
  id: string;
  user_id: string;
  amount_usd: number;
  balance_type: string;
  payment_method: string;
  payment_details: any;
  status: string;
  processed_at?: string;
  admin_notes: string;
  created_at: string;
}

export interface Gift {
  id: string;
  sender_id: string;
  receiver_id: string;
  live_room_id?: string;
  gift_type: string;
  coin_cost: number;
  usd_value: number;
  creator_share_usd: number;
  platform_share_usd: number;
  created_at: string;
}

// ========== LIVE ==========
export interface LiveRoom {
  id: string;
  host_id: string;
  title: string;
  viewer_count: number;
  total_gifts_usd: number;
  stream_key: string;
  is_active: boolean;
  started_at: string;
  ended_at?: string;
  host?: User;
}

export interface LiveChat {
  id: string;
  live_room_id: string;
  user_id: string;
  message: string;
  created_at: string;
  user?: User;
}

export interface LiveGame {
  id: string;
  live_room_id: string;
  game_type: string;
  game_data: any;
  results: any;
  is_active: boolean;
  created_at: string;
}

// ========== NOTIFICATIONS & REPORTS ==========
export interface Notification {
  id: string;
  user_id: string;
  actor_id?: string;
  type: string;
  reference_id?: string;
  message: string;
  is_read: boolean;
  created_at: string;
  actor?: User;
}

export interface Report {
  id: string;
  reporter_id: string;
  reported_user_id?: string;
  reported_video_id?: string;
  reason: string;
  description: string;
  status: string;
  reviewed_by?: string;
  created_at: string;
}

// ========== MUSIC & AUDIT ==========
export interface Music {
  id: string;
  title: string;
  artist: string;
  audio_url: string;
  duration: number;
  fingerprint: string;
  is_licensed: boolean;
  created_at: string;
}

export interface AuditLog {
  id: string;
  action: string;
  user_id?: string;
  admin_id?: string;
  details: any;
  created_at: string;
}
