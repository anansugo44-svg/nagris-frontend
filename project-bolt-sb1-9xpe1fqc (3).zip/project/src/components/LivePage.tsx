import { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Video as VideoIcon, Play, Users, Radio, Plus, X } from 'lucide-react';
import { liveApi, type LiveStream } from '../lib/liveApi';
import type { User } from '../lib/types';
import LiveStreamViewer from './LiveStreamViewer';

export default function LivePage() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const roomId = searchParams.get('room');

  const [liveStreams, setLiveStreams] = useState<LiveStream[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [canStart, setCanStart] = useState(false);
  const [followerCount, setFollowerCount] = useState(0);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [creating, setCreating] = useState(false);

  useEffect(() => {
    loadLiveStreams();
    checkEligibility();
  }, []);

  const loadLiveStreams = async () => {
    try {
      const streams = await liveApi.getActiveLiveStreams();
      setLiveStreams(streams);
    } catch (err) {
      console.error('Failed to load live streams:', err);
    } finally {
      setLoading(false);
    }
  };

  const checkEligibility = async () => {
    try {
      const { canStart: eligible, followerCount: count } = await liveApi.canStartLive();
      setCanStart(eligible);
      setFollowerCount(count);
    } catch (err) {
      console.error('Failed to check eligibility:', err);
    }
  };

  const handleCreateLive = async () => {
    if (!title.trim()) {
      alert('Please enter a title for your live stream');
      return;
    }

    setCreating(true);
    try {
      const stream = await liveApi.startLive(title, description);
      navigate(`/live?room=${stream.id}`);
    } catch (err: any) {
      alert(err.message || 'Failed to start live stream');
    } finally {
      setCreating(false);
    }
  };

  if (roomId) {
    return <LiveStreamViewer streamId={roomId} onClose={() => navigate('/live')} />;
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center">
          <Radio size={48} className="mx-auto text-red-500 animate-pulse mb-3" />
          <p className="text-slate-600">Loading live streams...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white pb-20">
      <div className="max-w-6xl mx-auto p-4">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
              <Radio className="text-red-500" />
              Live Streams
            </h1>
            <p className="text-slate-600 text-sm mt-1">Watch and interact with live broadcasts</p>
          </div>

          <button
            onClick={() => setShowCreateModal(true)}
            className={`flex items-center gap-2 px-6 py-3 rounded-xl font-semibold transition-all ${
              canStart
                ? 'bg-red-500 text-white hover:bg-red-600 shadow-lg'
                : 'bg-slate-200 text-slate-500 cursor-not-allowed'
            }`}
            disabled={!canStart}
          >
            <Plus size={20} />
            Go Live
          </button>
        </div>

        {!canStart && (
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 mb-6">
            <p className="text-amber-800 text-sm">
              <strong>Need {500 - followerCount} more followers</strong> to start live streaming.
              You currently have {followerCount} followers.
            </p>
          </div>
        )}

        {liveStreams.length === 0 ? (
          <div className="text-center py-16">
            <Radio size={64} className="mx-auto text-slate-300 mb-4" />
            <h3 className="text-xl font-semibold text-slate-700 mb-2">No Live Streams</h3>
            <p className="text-slate-500">Check back later for live content</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {liveStreams.map((stream) => (
              <div
                key={stream.id}
                onClick={() => navigate(`/live?room=${stream.id}`)}
                className="relative aspect-video bg-slate-900 rounded-xl overflow-hidden cursor-pointer group hover:scale-105 transition-transform"
              >
                {stream.thumbnail_url ? (
                  <img
                    src={stream.thumbnail_url}
                    alt={stream.title}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-red-500 to-pink-500">
                    <VideoIcon size={48} className="text-white opacity-50" />
                  </div>
                )}

                <div className="absolute top-3 left-3 bg-red-500 text-white px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1 animate-pulse">
                  <div className="w-2 h-2 bg-white rounded-full"></div>
                  LIVE
                </div>

                <div className="absolute top-3 right-3 bg-black/60 backdrop-blur-sm text-white px-2 py-1 rounded-lg text-xs font-semibold flex items-center gap-1">
                  <Users size={14} />
                  {stream.viewer_count}
                </div>

                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <img
                      src={stream.user?.avatar_url || 'https://via.placeholder.com/32'}
                      alt={stream.user?.username}
                      className="w-8 h-8 rounded-full border-2 border-white"
                    />
                    <div className="flex-1 min-w-0">
                      <p className="text-white font-semibold text-sm truncate">
                        {stream.user?.username}
                        {stream.user?.is_verified && (
                          <span className="ml-1">✓</span>
                        )}
                      </p>
                    </div>
                  </div>
                  <p className="text-white text-sm font-medium truncate">{stream.title}</p>
                </div>

                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors flex items-center justify-center">
                  <Play size={48} className="text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {showCreateModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-slate-900">Start Live Stream</h2>
              <button
                onClick={() => setShowCreateModal(false)}
                className="p-2 hover:bg-slate-100 rounded-full transition-colors"
              >
                <X size={20} />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Title <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="What's your stream about?"
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
                  maxLength={100}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Description
                </label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Tell viewers what to expect..."
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500 h-24 resize-none"
                  maxLength={500}
                />
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                <p className="text-blue-800 text-xs">
                  <strong>Tip:</strong> Your live stream will be visible to all users. Make sure your content follows community guidelines.
                </p>
              </div>
            </div>

            <div className="flex gap-3 mt-6">
              <button
                onClick={() => setShowCreateModal(false)}
                className="flex-1 px-4 py-3 bg-slate-200 text-slate-700 rounded-xl font-semibold hover:bg-slate-300 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleCreateLive}
                disabled={creating || !title.trim()}
                className="flex-1 px-4 py-3 bg-red-500 text-white rounded-xl font-semibold hover:bg-red-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {creating ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    Starting...
                  </>
                ) : (
                  <>
                    <Radio size={20} />
                    Go Live
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
