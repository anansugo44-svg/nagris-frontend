import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { X, Send, Heart, Trash2, Pin } from 'lucide-react';
import type { Video, Comment } from '../lib/types';  // ✅ use types.ts, not supabase
import { api } from '../lib/api';
import { useAuth } from '../lib/newAuthContext';  // ✅ custom auth
import type { User } from '../lib/types';

interface CommentsModalProps {
  video: Video;
  onClose: () => void;
}

export default function CommentsModal({ video, onClose }: CommentsModalProps) {
  const navigate = useNavigate();
  const { user } = useAuth(); // ✅ logged-in user
  const [comments, setComments] = useState<Comment[]>([]);
  const [newComment, setNewComment] = useState('');
  const [replyingTo, setReplyingTo] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [currentUserId, setCurrentUserId] = useState<string>('');
  const [commentLikes, setCommentLikes] = useState<Record<string, boolean>>({});
  const [isVideoOwner, setIsVideoOwner] = useState(false);

  useEffect(() => {
    loadComments();
    if (user) {
      setCurrentUserId(user.id);
      setIsVideoOwner(user.id === video.user_id);
    }
  }, [video.id, user]);

  const loadComments = async () => {
    try {
      const data = await api.getComments(video.id);

      const sortedComments = data.sort((a, b) => {
        if (a.is_pinned && !b.is_pinned) return -1;
        if (!a.is_pinned && b.is_pinned) return 1;
        return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
      });

      setComments(sortedComments);

      const allCommentIds: string[] = [];
      sortedComments.forEach(comment => {
        allCommentIds.push(comment.id);
        if (comment.replies) {
          comment.replies.forEach(reply => allCommentIds.push(reply.id));
        }
      });

      if (allCommentIds.length > 0) {
        const likedStates = await api.getCommentLikedStates(allCommentIds);
        setCommentLikes(likedStates);
      }
    } catch (err) {
      console.error('Failed to load comments:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim()) return;

    try {
      await api.addComment(video.id, newComment, replyingTo || undefined);
      setNewComment('');
      setReplyingTo(null);
      loadComments();
    } catch (err) {
      console.error('Failed to add comment:', err);
    }
  };

  const handleDelete = async (commentId: string) => {
    if (!confirm('Are you sure you want to delete this comment?')) return;

    try {
      await api.deleteComment(commentId);
      loadComments();
    } catch (err) {
      console.error('Failed to delete comment:', err);
    }
  };

  const handleLikeComment = async (commentId: string) => {
    const isLiked = commentLikes[commentId];
    const newLikedState = !isLiked;

    setCommentLikes(prev => ({
      ...prev,
      [commentId]: newLikedState
    }));

    setComments(prevComments =>
      prevComments.map(comment => {
        if (comment.id === commentId) {
          return {
            ...comment,
            likes_count: (comment.likes_count || 0) + (newLikedState ? 1 : -1)
          };
        }
        if (comment.replies) {
          return {
            ...comment,
            replies: comment.replies.map(reply =>
              reply.id === commentId
                ? { ...reply, likes_count: (reply.likes_count || 0) + (newLikedState ? 1 : -1) }
                : reply
            )
          };
        }
        return comment;
      })
    );

    try {
      if (newLikedState) {
        await api.likeComment(commentId);
      } else {
        await api.unlikeComment(commentId);
      }
    } catch (err) {
      console.error('Failed to like comment:', err);
      setCommentLikes(prev => ({
        ...prev,
        [commentId]: isLiked
      }));
      loadComments();
    }
  };

  const handlePinComment = async (commentId: string, isPinned: boolean) => {
    try {
      if (isPinned) {
        await api.unpinComment(video.id, commentId);
      } else {
        await api.pinComment(video.id, commentId);
      }
      loadComments();
    } catch (err) {
      console.error('Failed to pin/unpin comment:', err);
      alert('Failed to pin comment. Only one comment can be pinned at a time.');
    }
  };

  const goToProfile = (userId: string) => {
    navigate(`/profile/${userId}`);
    onClose();
  };

  const formatCount = (count: number): string => {
    if (count >= 1000) {
      return (count / 1000).toFixed(1) + 'K';
    }
    return count.toString();
  };

  const renderComment = (comment: Comment, isReply = false) => (
    <div key={comment.id} className={`flex gap-3 ${isReply ? 'ml-6' : ''}`}>
      <img
        src={comment.user?.avatar_url || 'https://via.placeholder.com/40'}
        alt={comment.user?.username}
        onClick={() => comment.user?.id && goToProfile(comment.user.id)}
        className={`${isReply ? 'w-8 h-8' : 'w-10 h-10'} rounded-full flex-shrink-0 cursor-pointer hover:opacity-80 transition-opacity`}
      />
      <div className="flex-1">
        <div className={`bg-slate-800 rounded-lg p-3 ${isReply ? 'bg-slate-800/50' : ''}`}>
          <div className="flex items-start justify-between mb-1">
            <div className="flex items-center gap-2">
              {comment.is_pinned && !isReply && (
                <div className="bg-cyan-500 rounded p-1">
                  <Pin size={12} className="text-white" />
                </div>
              )}
              <p
                onClick={() => comment.user?.id && goToProfile(comment.user.id)}
                className={`text-white font-semibold ${isReply ? 'text-xs' : 'text-sm'} cursor-pointer hover:underline`}
              >
                @{comment.user?.username}
              </p>
              {comment.user?.is_verified && (
                <div className="bg-cyan-500 rounded-full p-0.5">
                  <svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M6.267 3.455a3.066 3.066 0 001.745-.723 3.066 3.066 0 013.976 0 3.066 3.066 0 001.745.723 3.066 3.066 0 012.812 2.812c.051.643.304 1.254.723 1.745a3.066 3.066 0 010 3.976 3.066 3.066 0 00-.723 1.745 3.066 3.066 0 01-2.812 2.812 3.066 3.066 0 00-1.745.723 3.066 3.066 0 01-3.976 0 3.066 3.066 0 00-1.745-.723 3.066 3.066 0 01-2.812-2.812 3.066 3.066 0 00-.723-1.745 3.066 3.066 0 010-3.976 3.066 3.066 0 00.723-1.745 3.066 3.066 0 012.812-2.812zm7.44 5.252a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" />
                  </svg>
                </div>
              )}
            </div>
            <div className="flex items-center gap-2">
              {isVideoOwner && !isReply && (
                <button
                  onClick={() => handlePinComment(comment.id, comment.is_pinned || false)}
                  className={`transition-colors ${
                    comment.is_pinned
                      ? 'text-cyan-400 hover:text-cyan-300'
                      : 'text-slate-400 hover:text-cyan-400'
                  }`}
                  title={comment.is_pinned ? 'Unpin comment' : 'Pin comment'}
                >
                  <Pin size={14} />
                </button>
              )}
              {comment.user_id === currentUserId && (
                <button
                  onClick={() => handleDelete(comment.id)}
                  className="text-slate-400 hover:text-red-400 transition-colors"
                >
                  <Trash2 size={14} />
                </button>
              )}
            </div>
          </div>
          <p className={`text-slate-200 ${isReply ? 'text-xs' : 'text-sm'}`}>{comment.content}</p>
        </div>

        <div className="flex items-center gap-4 mt-2 text-xs">
          <span className="text-slate-500">
            {new Date(comment.created_at).toLocaleDateString()}
          </span>
          <button
            onClick={() => handleLikeComment(comment.id)}
            className={`flex items-center gap-1 transition-colors ${
              commentLikes[comment.id]
                ? 'text-red-400 hover:text-red-300'
                : 'text-slate-400 hover:text-red-400'
            }`}
          >
            <Heart size={14} fill={commentLikes[comment.id] ? 'currentColor' : 'none'} />
            {comment.likes_count > 0 && (
              <span className="font-medium">{formatCount(comment.likes_count)}</span>
            )}
          </button>
          {!isReply && (
            <button
              onClick={() => setReplyingTo(comment.id)}
              className="text-cyan-400 hover:text-cyan-300 font-medium"
            >
              Reply
            </button>
          )}
        </div>

        {comment.replies && comment.replies.length > 0 && (
          <div className="mt-3 space-y-2">
            {comment.replies.map((reply) => renderComment(reply, true))}
          </div>
        )}
      </div>
    </div>
  );

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-end md:items-center justify-center">
      <div className="bg-slate-900 w-full md:max-w-2xl md:rounded-t-2xl md:rounded-b-2xl max-h-[90vh] flex flex-col">
        <div className="flex items-center justify-between p-4 border-b border-slate-700">
          <h2 className="text-white font-semibold text-lg">
            Comments ({video.comments_count})
          </h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-slate-800 rounded-full transition-colors"
          >
            <X className="text-white" size={24} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {loading ? (
            <div className="text-center text-slate-400 py-8">Loading comments...</div>
          ) : comments.length === 0 ? (
            <div className="text-center text-slate-400 py-8">
              No comments yet. Be the first to comment!
            </div>
          ) : (
            comments.map((comment) => (
              <div key={comment.id} className="space-y-2">
                {renderComment(comment)}
              </div>
            ))
          )}
        </div>

        <form onSubmit={handleSubmit} className="p-4 border-t border-slate-700">
          {replyingTo && (
            <div className="mb-2 flex items-center justify-between bg-slate-800 px-3 py-2 rounded-lg">
              <span className="text-sm text-slate-400">Replying to comment</span>
              <button
                type="button"
                onClick={() => setReplyingTo(null)}
                className="text-slate-400 hover:text-white"
              >
                <X size={16} />
              </button>
            </div>
          )}
          <div className="flex gap-2">
            <input
              type="text"
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              placeholder="Add a comment..."
              className="flex-1 bg-slate-800 text-white rounded-full px-4 py-2 focus:outline-none focus:ring-2 focus:ring-cyan-500"
            />
            <button
              type="submit"
              disabled={!newComment.trim()}
              className="bg-gradient-to-r from-cyan-500 to-orange-500 text-white p-2 rounded-full hover:from-cyan-600 hover:to-orange-600 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Send size={20} />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
