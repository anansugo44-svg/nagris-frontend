import { useState, useEffect } from 'react';
import { DollarSign, TrendingUp, Gift, Calendar, AlertCircle, Check, Eye, Heart, Users, Shield, Award } from 'lucide-react';
import type { User } from '../lib/types';
import { getMonetizationEligibility, getUserVerification, isEligibleCountry, getCountryName, refreshMonetizationStatus } from '../lib/verification';
import { getWalletEarnings, requestWithdrawal } from '../lib/gifts';
import { useAuth } from '../lib/newAuthContext';  // ✅ use custom auth

export default function WalletPage() {
  const { user } = useAuth(); // ✅ current logged-in user
  const [earnings, setEarnings] = useState<any>(null);
  const [eligibility, setEligibility] = useState<any>(null);
  const [verification, setVerification] = useState<any>(null);
  const [showWithdrawModal, setShowWithdrawModal] = useState(false);
  const [withdrawType, setWithdrawType] = useState<'views' | 'gifts'>('gifts');
  const [amount, setAmount] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('');
  const [paymentDetails, setPaymentDetails] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      loadWalletData(user.id);
    } else {
      setLoading(false);
    }
  }, [user]);

  const loadWalletData = async (userId: string) => {
    try {
      await refreshMonetizationStatus(userId);

      const [earningsData, eligibilityData, verificationData] = await Promise.all([
        getWalletEarnings(userId),
        getMonetizationEligibility(userId),
        getUserVerification(userId)
      ]);

      setEarnings(earningsData);
      setEligibility(eligibilityData);
      setVerification(verificationData);
    } catch (err) {
      console.error('Failed to load wallet data:', err);
    } finally {
      setLoading(false);
    }
  };

  const canWithdrawViews = () => {
    if (!eligibility || !verification?.is_verified) return false;
    return eligibility.eligible_for_view_payouts && eligibility.meets_requirements;
  };

  const getPaymentMethods = () => {
    if (!verification) return [];
    const country = verification.country_code;
    if (country === 'KE') return ['M-Pesa', 'PayPal', 'Bank Transfer'];
    if (country === 'SO') return ['EVC Plus', 'Zaad', 'Dahabshiil', 'PayPal'];
    return ['PayPal', 'Bank Transfer'];
  };

  const handleWithdraw = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!earnings || !user) return;

    const withdrawAmount = parseFloat(amount);
    if (withdrawAmount < 10) {
      alert('Minimum withdrawal amount is $10');
      return;
    }

    const maxAmount = withdrawType === 'views' ? earnings.view_earnings : earnings.gift_earnings;
    const availableAmount = maxAmount - (earnings.pending_withdrawal || 0);

    if (withdrawAmount > availableAmount) {
      alert('Insufficient balance');
      return;
    }

    try {
      const result = await requestWithdrawal(
        user.id,
        withdrawAmount,
        paymentMethod,
        { account: paymentDetails, type: withdrawType }
      );

      if (result.success) {
        alert('Withdrawal request submitted successfully!');
        setShowWithdrawModal(false);
        setAmount('');
        setPaymentDetails('');
        loadWalletData(user.id);
      } else {
        alert(result.message || 'Failed to submit withdrawal request');
      }
    } catch (err) {
      console.error('Failed to create withdrawal:', err);
      alert('Failed to create withdrawal request');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 flex items-center justify-center">
        <p className="text-white">Loading wallet...</p>
      </div>
    );
  }

  const totalBalance = (earnings?.view_earnings || 0) + (earnings?.gift_earnings || 0);
  const isVerified = verification?.is_verified || false;
  const isEligibleRegion = verification && isEligibleCountry(verification.country_code);
  const meetsRequirements = eligibility?.meets_requirements || false;

  const viewsRemaining = Math.max(0, 1000000 - (eligibility?.total_views || 0));
  const likesRemaining = Math.max(0, 20000 - (eligibility?.total_likes || 0));
  const followersRemaining = Math.max(0, 10000 - (eligibility?.total_followers || 0));

  const viewsProgress = Math.min(100, ((eligibility?.total_views || 0) / 1000000) * 100);
  const likesProgress = Math.min(100, ((eligibility?.total_likes || 0) / 20000) * 100);
  const followersProgress = Math.min(100, ((eligibility?.total_followers || 0) / 10000) * 100);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 p-4 pb-20">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold text-white mb-6">My Wallet</h1>

        {!isVerified && (
          <div className="bg-yellow-500/10 border border-yellow-500/50 rounded-lg p-4 mb-6">
            <div className="flex gap-3">
              <AlertCircle className="text-yellow-400 flex-shrink-0" size={24} />
              <div className="text-yellow-200">
                <p className="font-semibold mb-1">Verification Required</p>
                <p className="text-sm">Please verify your account in Settings to enable monetization features.</p>
              </div>
            </div>
          </div>
        )}

        <div className="bg-gradient-to-r from-cyan-500 to-orange-500 rounded-2xl p-6 mb-6">
          <p className="text-white/80 text-sm mb-2">Total Balance</p>
          <p className="text-white text-4xl font-bold mb-4">${totalBalance.toFixed(2)}</p>
          <div className="flex gap-4 text-white/90 text-sm">
            <div>
              <p className="font-medium">Total Earned</p>
              <p className="text-2xl font-bold">${(earnings?.total_earnings || 0).toFixed(2)}</p>
            </div>
            <div>
              <p className="font-medium">Total Withdrawn</p>
              <p className="text-2xl font-bold">${(earnings?.total_withdrawn || 0).toFixed(2)}</p>
            </div>
          </div>
        </div>

        <div className="bg-cyan-500/10 border border-cyan-500/50 rounded-lg p-4 mb-6">
          <div className="flex gap-2 mb-2">
            <Calendar className="text-cyan-400 flex-shrink-0" size={20} />
            <div className="text-sm text-cyan-200">
              <p className="font-semibold mb-1">Payout Schedule</p>
              <p>• Gift payouts: Processed weekly (Fridays)</p>
              <p>• View payouts: Processed monthly (20th-25th)</p>
            </div>
          </div>
        </div>

        {isVerified && isEligibleRegion && !meetsRequirements && (
          <div className="bg-slate-800/50 backdrop-blur-lg rounded-xl border border-slate-700 p-6 mb-6">
            <div className="flex items-center gap-3 mb-4">
              <Award className="text-cyan-400" size={28} />
              <div>
                <h2 className="text-xl font-bold text-white">Monetization Requirements</h2>
                <p className="text-slate-400 text-sm">Complete all three to start earning from views</p>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <Eye className="text-purple-400" size={20} />
                    <span className="text-white font-medium">1,000,000 Total Views</span>
                  </div>
                  <span className="text-slate-400 text-sm">
                    {viewsRemaining > 0 ? `${viewsRemaining.toLocaleString()} remaining` : '✓ Complete'}
                  </span>
                </div>
                <div className="w-full bg-slate-700 rounded-full h-2">
                  <div
                    className="bg-purple-500 h-2 rounded-full transition-all duration-500"
                    style={{ width: `${viewsProgress}%` }}
                  />
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  {(eligibility?.total_views || 0).toLocaleString()} views
                </p>
              </div>

              <div>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <Heart className="text-pink-400" size={20} />
                    <span className="text-white font-medium">20,000 Total Likes</span>
                  </div>
                  <span className="text-slate-400 text-sm">
                    {likesRemaining > 0 ? `${likesRemaining.toLocaleString()} remaining` : '✓ Complete'}
                  </span>
                </div>
                <div className="w-full bg-slate-700 rounded-full h-2">
                  <div
                    className="bg-pink-500 h-2 rounded-full transition-all duration-500"
                    style={{ width: `${likesProgress}%` }}
                  />
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  {(eligibility?.total_likes || 0).toLocaleString()} likes
                </p>
              </div>

              <div>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <Users className="text-blue-400" size={20} />
                    <span className="text-white font-medium">10,000 Followers</span>
                  </div>
                  <span className="text-slate-400 text-sm">
                    {followersRemaining > 0 ? `${followersRemaining.toLocaleString()} remaining` : '✓ Complete'}
                  </span>
                </div>
                <div className="w-full bg-slate-700 rounded-full h-2">
                  <div
                    className="bg-blue-500 h-2 rounded-full transition-all duration-500"
                    style={{ width: `${followersProgress}%` }}
                  />
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  {(eligibility?.total_followers || 0).toLocaleString()} followers
                </p>
              </div>
            </div>

            <div className="mt-4 p-3 bg-cyan-500/10 border border-cyan-500/30 rounded-lg">
              <p className="text-cyan-300 text-xs">
                <Shield className="inline mr-1" size={14} />
                Only legitimate views, likes, and followers count toward requirements. Bot activity is automatically detected and excluded.
              </p>
            </div>
          </div>
        )}

        <div className="grid md:grid-cols-2 gap-4 mb-6">
          <div className="bg-slate-800/50 backdrop-blur-lg rounded-xl border border-slate-700 p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-3 bg-purple-500/20 rounded-lg">
                <TrendingUp className="text-purple-400" size={24} />
              </div>
              <div>
                <p className="text-slate-400 text-sm">Views Balance</p>
                <p className="text-white text-2xl font-bold">${(earnings?.view_earnings || 0).toFixed(2)}</p>
              </div>
            </div>
            {canWithdrawViews() ? (
              <button
                onClick={() => {
                  setWithdrawType('views');
                  setShowWithdrawModal(true);
                }}
                className="w-full py-2 bg-purple-500 text-white rounded-lg hover:bg-purple-600 transition-colors font-medium"
              >
                Withdraw
              </button>
            ) : (
              <div className="text-xs text-slate-400 p-3 bg-slate-700/50 rounded-lg">
                {!isVerified ? (
                  <p>Please verify your account to enable withdrawals</p>
                ) : !isEligibleRegion ? (
                  <p>View payouts coming soon in your country</p>
                ) : (
                  <p>Complete all requirements above to withdraw view earnings</p>
                )}
              </div>
            )}
          </div>

          <div className="bg-slate-800/50 backdrop-blur-lg rounded-xl border border-slate-700 p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-3 bg-orange-500/20 rounded-lg">
                <Gift className="text-orange-400" size={24} />
              </div>
              <div>
                <p className="text-slate-400 text-sm">Gifts Balance</p>
                <p className="text-white text-2xl font-bold">${(earnings?.gift_earnings || 0).toFixed(2)}</p>
              </div>
            </div>
            <button
              onClick={() => {
                setWithdrawType('gifts');
                setShowWithdrawModal(true);
              }}
              disabled={!isVerified || (earnings?.gift_earnings || 0) < 10}
              className="w-full py-2 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-colors font-medium disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Withdraw
            </button>
            {!isVerified && (
              <p className="text-xs text-slate-400 mt-2">Verification required to withdraw</p>
            )}
          </div>
        </div>

        {isVerified && verification && (
          <div className="bg-slate-800/50 backdrop-blur-lg rounded-xl border border-slate-700 p-4 mb-6">
            <div className="flex items-center gap-2 text-green-400 text-sm">
              <Check size={18} />
              <span>Verified • {getCountryName(verification.country_code)}</span>
            </div>
          </div>
        )}
      </div>

      {showWithdrawModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 rounded-2xl max-w-md w-full p-6 border border-slate-700">
            <h2 className="text-white font-semibold text-xl mb-4">
              Withdraw {withdrawType === 'views' ? 'Views' : 'Gifts'} Balance
            </h2>

            <form onSubmit={handleWithdraw} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Amount (USD)
                </label>
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
                  placeholder="10.00"
                  min="10"
                  step="0.01"
                  required
                />
                <p className="text-xs text-slate-500 mt-1">Minimum withdrawal: $10</p>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Payment Method
                </label>
                <select
                  value={paymentMethod}
                  onChange={(e) => setPaymentMethod(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
                  required
                >
                  <option value="">Select method</option>
                  {getPaymentMethods().map((method) => (
                    <option key={method} value={method}>{method}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Account Details
                </label>
                <input
                  type="text"
                  value={paymentDetails}
                  onChange={(e) => setPaymentDetails(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
                  placeholder="Phone number / Account ID"
                  required
                />
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowWithdrawModal(false)}
                  className="flex-1 px-4 py-3 bg-slate-800 text-white rounded-lg hover:bg-slate-700 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-3 bg-gradient-to-r from-cyan-500 to-orange-500 text-white rounded-lg hover:from-cyan-600 hover:to-orange-600 transition-all"
                >
                  Submit Request
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
