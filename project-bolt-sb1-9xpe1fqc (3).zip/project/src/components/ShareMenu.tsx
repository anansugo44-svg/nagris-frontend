import { useState } from "react";
import { api } from "../lib/api";
import {
  Share2,
  Download,
  Link,
  Flag,
  Users,
  MessageCircle,
  X,
  Share
} from "lucide-react";

function ShareMenu({
  video,
  onClose,
  onShared,
}: {
  video: any;
  onClose: () => void;
  onShared: () => void;
}) {
  const [showReport, setShowReport] = useState(false);
  const [reason, setReason] = useState("");
  const [description, setDescription] = useState("");
  const [message, setMessage] = useState("");

  // helper: increment share in backend
const recordShare = async () => {
  try {
    await api.shareVideo(video.id);   // call backend
    onShared();                       // update UI count in VideoPlayer
  } catch (err) {
    console.error("Failed to record share:", err);
  }
};
  
  // Copy link
  const handleCopyLink = async () => {
    const link = `${window.location.origin}/video/${video.id}`;
    await navigator.clipboard.writeText(link);
    setMessage("✅ Link copied!");
    setTimeout(() => setMessage(""), 2000);

    recordShare();
  };

  // WhatsApp share
  const handleShareWhatsApp = () => {
    const link = `${window.location.origin}/video/${video.id}`;
    window.open(`https://wa.me/?text=${encodeURIComponent(link)}`, "_blank");
    recordShare();
  };

  // Other platforms (native share if supported)
  const handleOtherShare = async () => {
    const link = `${window.location.origin}/video/${video.id}`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: video.title,
          text: "Check out this video on Nagris!",
          url: link,
        });
        recordShare();
      } catch {
        // cancelled
      }
    } else {
      handleCopyLink();
    }
  };

  // Download
  const handleDownload = () => {
    const a = document.createElement("a");
    a.href = video.video_url;
    a.download = `video-${video.id}.mp4`;
    a.click();
  };

  // Submit report
  const handleReport = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api.reportContent("video", video.id, reason, description);
      setMessage("✅ Report submitted. Thank you!");
      setShowReport(false);
      setReason("");
      setDescription("");
    } catch (err: any) {
      setMessage(err.message || "Failed to submit report");
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 backdrop-blur-sm">
      {/* Click outside to close */}
      <div className="absolute inset-0" onClick={onClose}></div>

      <div className="relative w-full max-w-md bg-slate-900 rounded-t-2xl p-6 animate-slideUp z-10">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-white text-lg font-semibold">Share</h3>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white"
          >
            <X size={22} />
          </button>
        </div>

        {!showReport ? (
          <div className="space-y-3">
            <button
              onClick={handleDownload}
              className="flex items-center gap-2 w-full px-4 py-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-white"
            >
              <Download size={18} /> Download
            </button>

            <button
              onClick={handleCopyLink}
              className="flex items-center gap-2 w-full px-4 py-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-white"
            >
              <Link size={18} /> Copy Link
            </button>

            <button
              onClick={handleShareWhatsApp}
              className="flex items-center gap-2 w-full px-4 py-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-white"
            >
              <MessageCircle size={18} /> WhatsApp
            </button>

            <button
              onClick={handleOtherShare}
              className="flex items-center gap-2 w-full px-4 py-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-white"
            >
              <Share size={18} /> Other Platforms
            </button>

            <button
              onClick={() => setShowReport(true)}
              className="flex items-center gap-2 w-full px-4 py-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-red-400"
            >
              <Flag size={18} /> Report Video
            </button>

            <button
              onClick={() => alert("🎤 Duet coming soon!")}
              className="flex items-center gap-2 w-full px-4 py-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-white"
            >
              <Users size={18} /> Duet
            </button>

            {message && (
              <p className="text-xs text-green-400 text-center">{message}</p>
            )}
          </div>
        ) : (
          <form onSubmit={handleReport} className="space-y-3">
            <h4 className="text-white font-semibold">Report Video</h4>

            <select
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              className="w-full px-3 py-2 bg-slate-700 border border-slate-600 text-white rounded"
              required
            >
              <option value="">Select a reason</option>
              <option value="violence">Violence</option>
              <option value="nudity">Nudity / Sexual</option>
              <option value="spam">Spam / Misleading</option>
              <option value="hate">Hate Speech</option>
              <option value="other">Other</option>
            </select>

            <textarea
              placeholder="Details (optional)"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-3 py-2 bg-slate-700 border border-slate-600 text-white rounded resize-none"
              rows={3}
            />

            <button
              type="submit"
              className="w-full py-2 bg-red-500 text-white rounded hover:bg-red-600"
            >
              Submit Report
            </button>
          </form>
        )}
      </div>
    </div>
  );
}

export default ShareMenu;
