import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, UserPlus } from 'lucide-react';
import { api } from '../lib/api';
import type { User, Video } from '../lib/types'; // ✅ fixed to use shared types

export default function SearchPage() {
  const navigate = useNavigate();
  const [query, setQuery] = useState('');
  const [users, setUsers] = useState<User[]>([]);
  const [videos, setVideos] = useState<Video[]>([]);
  const [loading, setLoading] = useState(false);
  const [followingIds, setFollowingIds] = useState<Set<string>>(new Set());

  const handleSearch = async (searchQuery: string) => {
    setQuery(searchQuery);
    if (!searchQuery.trim()) {
      setUsers([]);
      setVideos([]);
      return;
    }

    setLoading(true);
    try {
      const results = await api.search(searchQuery);
      setUsers(results.users);
      setVideos(results.videos);

      const currentFollowing = await api.getFollowingIds();
      setFollowingIds(new Set(currentFollowing));
    } catch (err) {
      console.error('Search failed:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleFollow = async (userId: string) => {
    try {
      if (followingIds.has(userId)) {
        await api.unfollowUser(userId);
        setFollowingIds(prev => {
          const next = new Set(prev);
          next.delete(userId);
          return next;
        });
      } else {
        await api.followUser(userId);
        setFollowingIds(prev => new Set([...prev, userId]));
      }
    } catch (err) {
      console.error('Failed to follow/unfollow:', err);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 pb-20">
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="mb-6">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
            <input
              type="text"
              value={query}
              onChange={(e) => handleSearch(e.target.value)}
              placeholder="Search users and videos..."
              className="w-full pl-12 pr-4 py-4 bg-slate-800/50 backdrop-blur-lg border border-slate-700 rounded-full text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-cyan-500"
            />
          </div>
        </div>

        {loading ? (
          <div className="text-center py-12">
            <p className="text-white">Searching...</p>
          </div>
        ) : (
          <>
            {users.length > 0 && (
              <div className="mb-8">
                <h2 className="text-xl font-bold text-white mb-4">Users</h2>
                <div className="space-y-3">
                  {users.map((user) => (
                    <div
                      key={user.id}
                      onClick={() => navigate(`/profile/${user.id}`)}
                      className="flex items-center gap-4 p-4 bg-slate-800/50 backdrop-blur-lg rounded-xl border border-slate-700 hover:border-cyan-500 transition-colors cursor-pointer"
                    >
                      <img
                        src={user.avatar_url || 'https://via.placeholder.com/50'}
                        alt={user.username}
                        className="w-12 h-12 rounded-full"
                      />
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <p className="text-white font-semibold">@{user.username}</p>
                          {user.is_verified && (
                            <div className="bg-cyan-500 rounded-full p-0.5">
                              <svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 20 20">
                                <path d="M6.267 3.455a3.066 3.066 0 001.745-.723 3.066 3.066 0 013.976 0 3.066 3.066 0 001.745.723 3.066 3.066 0 012.812 2.812c.051.643.304 1.254.723 1.745a3.066 3.066 0 010 3.976 3.066 3.066 0 00-.723 1.745 3.066 3.066 0 01-2.812 2.812 3.066 3.066 0 00-1.745.723 3.066 3.066 0 01-3.976 0 3.066 3.066 0 00-1.745-.723 3.066 3.066 0 01-2.812-2.812 3.066 3.066 0 00-.723-1.745 3.066 3.066 0 010-3.976 3.066 3.066 0 00.723-1.745 3.066 3.066 0 012.812-2.812zm7.44 5.252a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" />
                              </svg>
                            </div>
                          )}
                        </div>
                        <p className="text-slate-400 text-sm">{user.followers_count} followers</p>
                      </div>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleFollow(user.id);
                        }}
                        className={`px-4 py-2 rounded-lg transition-all flex items-center gap-2 ${
                          followingIds.has(user.id)
                            ? 'bg-slate-700 text-white hover:bg-slate-600'
                            : 'bg-gradient-to-r from-cyan-500 to-orange-500 text-white hover:from-cyan-600 hover:to-orange-600'
                        }`}
                      >
                        <UserPlus size={16} />
                        {followingIds.has(user.id) ? 'Following' : 'Follow'}
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {videos.length > 0 && (
              <div>
                <h2 className="text-xl font-bold text-white mb-4">Videos</h2>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {videos.map((video) => (
                    <div
                      key={video.id}
                      onClick={() => navigate(`/?video=${video.id}`)}
                      className="aspect-[9/16] bg-slate-800 rounded-lg overflow-hidden cursor-pointer hover:opacity-80 transition-opacity relative group"
                    >
                      <img
                        src={video.thumbnail_url || 'https://via.placeholder.com/200x350'}
                        alt={video.title}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                      <div className="absolute bottom-0 left-0 right-0 p-3">
                        <p className="text-white text-sm font-medium line-clamp-2">{video.title}</p>
                        <div className="flex items-center gap-2 mt-1">
                          <img
                            src={video.user?.avatar_url || 'https://via.placeholder.com/24'}
                            alt={video.user?.username}
                            className="w-5 h-5 rounded-full"
                          />
                          <p className="text-white/80 text-xs">{video.user?.username}</p>
                        </div>
                        <p className="text-white/60 text-xs mt-1">
                          {video.views_count.toLocaleString()} views
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {query && !loading && users.length === 0 && videos.length === 0 && (
              <div className="text-center py-12">
                <p className="text-slate-400">No results found for "{query}"</p>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
