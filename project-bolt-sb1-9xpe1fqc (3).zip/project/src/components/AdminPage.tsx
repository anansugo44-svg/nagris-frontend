import { useState, useEffect } from 'react';
import { Shield, DollarSign, Flag, CheckCircle, XCircle } from 'lucide-react';
import type { User } from '../lib/types';
import { api } from '../lib/api';
import { useAuth } from '../lib/newAuthContext'; // ✅ custom auth

export default function AdminPage() {
  const { user } = useAuth(); // ✅ logged-in admin user
  const [activeTab, setActiveTab] = useState<'payouts' | 'reports'>('payouts');
  const [withdrawals, setWithdrawals] = useState<any[]>([]);
  const [reports, setReports] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (activeTab === 'payouts') {
      loadWithdrawals();
    } else {
      loadReports();
    }
  }, [activeTab]);

  const loadWithdrawals = async () => {
    setLoading(true);
    try {
      const data = await api.getWithdrawals(); // ✅ new API call
      setWithdrawals(data || []);
    } catch (err) {
      console.error('Failed to load withdrawals:', err);
    } finally {
      setLoading(false);
    }
  };

  const loadReports = async () => {
    setLoading(true);
    try {
      const data = await api.getReports(); // ✅ new API call
      setReports(data || []);
    } catch (err) {
      console.error('Failed to load reports:', err);
    } finally {
      setLoading(false);
    }
  };

  const updateWithdrawal = async (id: string, status: string, notes: string = '') => {
    try {
      await api.updateWithdrawal(id, { status, notes }); // ✅ new API call
      loadWithdrawals();
    } catch (err) {
      console.error('Failed to update withdrawal:', err);
    }
  };

  const updateReport = async (id: string, status: string) => {
    if (!user) return;
    try {
      await api.updateReport(id, { status, reviewedBy: user.id }); // ✅ new API call
      loadReports();
    } catch (err) {
      console.error('Failed to update report:', err);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 pb-20">
      <div className="max-w-6xl mx-auto px-4 py-8">
        <div className="flex items-center gap-3 mb-6">
          <Shield className="text-cyan-400" size={32} />
          <h1 className="text-3xl font-bold text-white">Admin Dashboard</h1>
        </div>

        <div className="flex gap-4 mb-6">
          <button
            onClick={() => setActiveTab('payouts')}
            className={`flex items-center gap-2 px-6 py-3 rounded-lg font-medium transition-colors ${
              activeTab === 'payouts'
                ? 'bg-gradient-to-r from-cyan-500 to-orange-500 text-white'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            <DollarSign size={20} />
            Withdrawal Requests
          </button>
          <button
            onClick={() => setActiveTab('reports')}
            className={`flex items-center gap-2 px-6 py-3 rounded-lg font-medium transition-colors ${
              activeTab === 'reports'
                ? 'bg-gradient-to-r from-cyan-500 to-orange-500 text-white'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            <Flag size={20} />
            Reports
          </button>
        </div>

        {loading ? (
          <div className="text-center py-12">
            <p className="text-white">Loading...</p>
          </div>
        ) : activeTab === 'payouts' ? (
          <div className="bg-slate-800/50 backdrop-blur-lg rounded-2xl border border-slate-700 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-slate-700/50">
                  <tr>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-white">User</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-white">Amount</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-white">Type</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-white">Method</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-white">Date</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-white">Status</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-white">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-700">
                  {withdrawals.map((w) => (
                    <tr key={w.id} className="hover:bg-slate-700/30">
                      <td className="px-6 py-4">
                        <div className="text-white font-medium">{w.user?.username}</div>
                        <div className="text-slate-400 text-sm">{w.user?.email}</div>
                        <div className="text-slate-500 text-xs">{w.user?.country}</div>
                      </td>
                      <td className="px-6 py-4 text-white font-semibold">${w.amount_usd}</td>
                      <td className="px-6 py-4">
                        <span className={`px-2 py-1 rounded text-xs font-medium ${
                          w.balance_type === 'views' ? 'bg-purple-500/20 text-purple-400' : 'bg-orange-500/20 text-orange-400'
                        }`}>
                          {w.balance_type}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-slate-300">{w.payment_method}</td>
                      <td className="px-6 py-4 text-slate-400 text-sm">
                        {new Date(w.created_at).toLocaleDateString()}
                      </td>
                      <td className="px-6 py-4">
                        <span className={`px-2 py-1 rounded text-xs font-medium ${
                          w.status === 'paid' ? 'bg-green-500/20 text-green-400' :
                          w.status === 'pending' ? 'bg-yellow-500/20 text-yellow-400' :
                          w.status === 'denied' ? 'bg-red-500/20 text-red-400' :
                          'bg-blue-500/20 text-blue-400'
                        }`}>
                          {w.status}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        {w.status === 'pending' && (
                          <div className="flex gap-2">
                            <button
                              onClick={() => updateWithdrawal(w.id, 'approved', 'Approved for payment')}
                              className="p-2 bg-green-500/20 text-green-400 rounded hover:bg-green-500/30"
                              title="Approve"
                            >
                              <CheckCircle size={16} />
                            </button>
                            <button
                              onClick={() => updateWithdrawal(w.id, 'denied', 'Denied due to verification issues')}
                              className="p-2 bg-red-500/20 text-red-400 rounded hover:bg-red-500/30"
                              title="Deny"
                            >
                              <XCircle size={16} />
                            </button>
                          </div>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            {reports.map((report) => (
              <div key={report.id} className="bg-slate-800/50 backdrop-blur-lg rounded-xl border border-slate-700 p-6">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <Flag className="text-orange-400" size={20} />
                      <span className={`px-2 py-1 rounded text-xs font-medium ${
                        report.status === 'reviewed' ? 'bg-blue-500/20 text-blue-400' :
                        report.status === 'actioned' ? 'bg-green-500/20 text-green-400' :
                        'bg-yellow-500/20 text-yellow-400'
                      }`}>
                        {report.status}
                      </span>
                    </div>
                    <p className="text-white font-medium mb-1">{report.reason}</p>
                    <p className="text-slate-400 text-sm mb-2">{report.description}</p>
                    <div className="flex items-center gap-4 text-xs text-slate-500">
                      <span>Reporter: {report.reporter?.username}</span>
                      {report.reported_user && <span>User: {report.reported_user?.username}</span>}
                      {report.reported_video && <span>Video: {report.reported_video?.title}</span>}
                      <span>{new Date(report.created_at).toLocaleDateString()}</span>
                    </div>
                  </div>
                  {report.status === 'pending' && (
                    <div className="flex gap-2">
                      <button
                        onClick={() => updateReport(report.id, 'reviewed')}
                        className="px-3 py-1 bg-blue-500/20 text-blue-400 rounded text-sm hover:bg-blue-500/30"
                      >
                        Review
                      </button>
                      <button
                        onClick={() => updateReport(report.id, 'actioned')}
                        className="px-3 py-1 bg-green-500/20 text-green-400 rounded text-sm hover:bg-green-500/30"
                      >
                        Action Taken
                      </button>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
