import { useState, useEffect, useRef } from 'react';
import { Mail, ArrowRight, RefreshCw, Check, AlertCircle, Link as LinkIcon } from 'lucide-react';
import type { User } from '../lib/types';
import { useAuth } from '../lib/newAuthContext'; // ✅ custom auth
import { api } from '../lib/api'; // ✅ custom API

interface EmailVerificationProps {
  email: string;
  onVerificationComplete: () => void;
  onBack?: () => void;
}

export default function EmailVerification({ email, onVerificationComplete, onBack }: EmailVerificationProps) {
  const { user } = useAuth();
  const [verificationMethod, setVerificationMethod] = useState<'link' | 'code'>('link');
  const [code, setCode] = useState(['', '', '', '', '', '']);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const [resendCooldown, setResendCooldown] = useState(0);
  const [codeExpiry, setCodeExpiry] = useState<Date | null>(null);
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  useEffect(() => {
    if (resendCooldown > 0) {
      const timer = setTimeout(() => setResendCooldown(resendCooldown - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [resendCooldown]);

  useEffect(() => {
    if (codeExpiry) {
      const interval = setInterval(() => {
        const now = new Date();
        if (now >= codeExpiry) {
          setError('Verification code has expired. Please request a new code.');
          setCodeExpiry(null);
        }
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [codeExpiry]);

  const handleSendVerificationCode = async () => {
    if (!user) {
      setError('No user found');
      return;
    }

    setLoading(true);
    setError('');

    try {
      const result = await api.sendEmailVerificationCode(user.id, email);

      if (result.success) {
        setCodeExpiry(new Date(Date.now() + 10 * 60 * 1000));
        setResendCooldown(60);
        setVerificationMethod('code');

        alert(`Verification code sent to ${email}. Check your email and enter the 6-digit code below.`);

        setTimeout(() => {
          inputRefs.current[0]?.focus();
        }, 100);
      } else {
        setError(result.message || 'Failed to send verification code. Please try again.');
      }
    } catch (err: any) {
      console.error('Failed to send code:', err);
      setError('Failed to send verification code. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleCodeChange = (index: number, value: string) => {
    if (!/^\d*$/.test(value)) return;

    const newCode = [...code];
    newCode[index] = value.slice(-1);
    setCode(newCode);
    setError('');

    if (value && index < 5) {
      inputRefs.current[index + 1]?.focus();
    }

    if (newCode.every(digit => digit !== '') && newCode.join('').length === 6) {
      verifyCode(newCode.join(''));
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === 'Backspace' && !code[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };

  const handlePaste = (e: React.ClipboardEvent) => {
    e.preventDefault();
    const pastedData = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, 6);
    const newCode = pastedData.split('').concat(Array(6).fill('')).slice(0, 6);
    setCode(newCode);

    if (pastedData.length === 6) {
      verifyCode(pastedData);
    } else if (pastedData.length > 0) {
      const nextEmptyIndex = Math.min(pastedData.length, 5);
      inputRefs.current[nextEmptyIndex]?.focus();
    }
  };

  const verifyCode = async (codeString: string) => {
    if (!user) {
      setError('No user found');
      return;
    }

    setLoading(true);
    setError('');

    try {
      const result = await api.verifyEmailCode(user.id, codeString);

      if (result.success) {
        setSuccess(true);
        setTimeout(() => {
          onVerificationComplete();
        }, 2000);
      } else {
        setError(result.message || 'Invalid verification code. Please try again.');
        setCode(['', '', '', '', '', '']);
        inputRefs.current[0]?.focus();
      }
    } catch (err: any) {
      console.error('Verification error:', err);
      setError(err.message || 'Invalid verification code. Please try again.');
      setCode(['', '', '', '', '', '']);
      inputRefs.current[0]?.focus();
    } finally {
      setLoading(false);
    }
  };

  const getTimeRemaining = () => {
    if (!codeExpiry) return null;
    const now = new Date();
    const diff = Math.max(0, Math.floor((codeExpiry.getTime() - now.getTime()) / 1000));
    const minutes = Math.floor(diff / 60);
    const seconds = diff % 60;
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  if (success) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 flex items-center justify-center p-4">
        <div className="bg-slate-800/50 backdrop-blur-lg rounded-2xl border border-slate-700 p-8 max-w-md w-full text-center">
          <div className="w-20 h-20 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
            <Check className="text-green-500" size={40} />
          </div>
          <h2 className="text-2xl font-bold text-white mb-2">Email Verified!</h2>
          <p className="text-slate-400">Your account has been successfully verified. Redirecting...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 flex items-center justify-center p-4">
      <div className="bg-slate-800/50 backdrop-blur-lg rounded-2xl border border-slate-700 p-8 max-w-lg w-full">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-cyan-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
            <Mail className="text-cyan-400" size={32} />
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">Verify Your Email</h1>
          <p className="text-slate-400">
            We sent a verification email to <span className="text-white font-medium">{email}</span>
          </p>
        </div>

        <div className="space-y-6">
          <div className="bg-slate-700/30 rounded-xl p-4 border border-slate-600">
            <div className="flex items-start gap-3">
              <div className="flex-shrink-0 mt-1">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  verificationMethod === 'link' ? 'bg-cyan-500' : 'bg-slate-600'
                }`}>
                  <LinkIcon size={16} className="text-white" />
                </div>
              </div>
              <div className="flex-1">
                <h3 className="text-white font-semibold mb-1">Option 1: Click the Link</h3>
                <p className="text-slate-400 text-sm mb-3">
                  Check your inbox and click the verification link in the email we sent you.
                </p>
                <div className="text-xs text-slate-500">
                  ✓ Quick and easy • ✓ No code needed • ✓ One-click verification
                </div>
              </div>
            </div>
          </div>

          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-slate-600"></div>
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-4 bg-slate-800/50 text-slate-400">OR</span>
            </div>
          </div>

          <div className="bg-slate-700/30 rounded-xl p-4 border border-slate-600">
            <div className="flex items-start gap-3">
              <div className="flex-shrink-0 mt-1">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  verificationMethod === 'code' ? 'bg-cyan-500' : 'bg-slate-600'
                }`}>
                  <span className="text-white font-bold text-sm">123</span>
                </div>
              </div>
              <div className="flex-1">
                <h3 className="text-white font-semibold mb-1">Option 2: Enter Code</h3>
                <p className="text-slate-400 text-sm mb-3">
                  Request a 6-digit verification code to enter manually below.
                </p>

                {verificationMethod === 'code' ? (
                  <>
                    <div className="space-y-4">
                      <div className="flex gap-2 justify-center">
                        {code.map((digit, index) => (
                          <input
                            key={index}
                            ref={el => inputRefs.current[index] = el}
                            type="text"
                            inputMode="numeric"
                            maxLength={1}
                            value={digit}
                            onChange={(e) => handleCodeChange(index, e.target.value)}
                            onKeyDown={(e) => handleKeyDown(index, e)}
                            onPaste={index === 0 ? handlePaste : undefined}
                            className="w-12 h-14 text-center text-2xl font-bold bg-slate-700/50 border-2 border-slate-600 rounded-lg text-white focus:border-cyan-500 focus:outline-none transition-colors"
                            disabled={loading}
                          />
                        ))}
                      </div>

                      {codeExpiry && (
                        <div className="text-center">
                          <p className="text-sm text-slate-400">
                            Code expires in <span className="text-cyan-400 font-semibold">{getTimeRemaining()}</span>
                          </p>
                        </div>
                      )}

                      {error && (
                        <div className="flex items-center gap-2 p-3 bg-red-500/10 border border-red-500/50 rounded-lg">
                          <AlertCircle size={18} className="text-red-400 flex-shrink-0" />
                          <p className="text-red-400 text-sm">{error}</p>
                        </div>
                      )}

                      <button
                        onClick={handleSendVerificationCode}
                        disabled={resendCooldown > 0 || loading}
                        className="w-full py-2 text-cyan-400 hover:text-cyan-300 disabled:text-slate-500 disabled:cursor-not-allowed transition-colors flex items-center justify-center gap-2 text-sm font-medium"
                      >
                        <RefreshCw size={16} />
                        {resendCooldown > 0 ? `Resend code in ${resendCooldown}s` : 'Resend code'}
                      </button>
                    </div>
                  </>
                ) : (
                  <button
                    onClick={handleSendVerificationCode}
                    disabled={loading}
                    className="w-full py-3 bg-gradient-to-r from-cyan-500 to-orange-500 text-white font-semibold rounded-lg hover:from-cyan-600 hover:to-orange-600 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                  >
                    {loading ? 'Sending...' : 'Send Verification Code'}
                    <ArrowRight size={18} />
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>

        <div className="mt-8 p-4 bg-blue-500/10 border border-blue-500/30 rounded-lg">
          <h4 className="text-sm font-semibold text-blue-400 mb-2 flex items-center gap-2">
            <AlertCircle size={16} />
            Didn't receive the email?
          </h4>
          <ul className="text-xs text-slate-400 space-y-1 ml-6">
            <li>• Check your spam or junk folder</li>
            <li>• Make sure {email} is correct</li>
            <li>• Wait a few minutes for the email to arrive</li>
            <li>• Use the code option if email links don't work</li>
          </ul>
        </div>

        {onBack && (
          <button
            onClick={onBack}
            className="w-full mt-4 py-3 text-slate-400 hover:text-white transition-colors"
          >
            Back to Sign In
          </button>
        )}
      </div>
    </div>
  );
}
