import { Home, PlusSquare, Bell, User, Wallet, Radio } from 'lucide-react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../lib/authContext';

export default function BottomNav() {
  const navigate = useNavigate();
  const location = useLocation();
  const { requireAuth } = useAuth();

  const isActive = (path: string) => location.pathname === path;

  const handleNavigate = (path: string, requiresAuth: boolean = false) => {
    if (requiresAuth && !requireAuth()) {
      return;
    }
    navigate(path);
  };

  const navItems = [
    { path: '/', icon: Home, label: 'Home', requiresAuth: false },
    { path: '/live', icon: Radio, label: 'Live', requiresAuth: true },
    { path: '/upload', icon: PlusSquare, label: 'Upload', requiresAuth: true },
    { path: '/notifications', icon: Bell, label: 'Inbox', requiresAuth: true },
    { path: '/wallet', icon: Wallet, label: 'Wallet', requiresAuth: true },
    { path: '/profile', icon: User, label: 'Profile', requiresAuth: true },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-slate-900/95 backdrop-blur-lg border-t border-slate-800 z-40">
      <div className="flex justify-around items-center h-16 max-w-screen-xl mx-auto px-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const active = isActive(item.path);
          return (
            <button
              key={item.path}
              onClick={() => handleNavigate(item.path, item.requiresAuth)}
              className={`flex flex-col items-center justify-center flex-1 h-full transition-colors ${
                active ? 'text-cyan-400' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Icon size={24} className={active ? 'stroke-2' : ''} />
              <span className="text-xs mt-1 font-medium">{item.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
