import { useState, useEffect } from 'react';
import { Upload as UploadIcon, Music, Lock, Globe, X, Check, Camera } from 'lucide-react';
import { api } from '../lib/api';
import type { User } from '../lib/types';
import type { Music as MusicType } from '../lib/types';
import CameraRecorder from './CameraRecorder';

export default function UploadPage() {
  const [file, setFile] = useState<File | null>(null);
  const [caption, setCaption] = useState('');
  const [selectedMusic, setSelectedMusic] = useState('');
  const [isPrivate, setIsPrivate] = useState(false);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');
  const [musicLibrary, setMusicLibrary] = useState<MusicType[]>([]);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [showCamera, setShowCamera] = useState(false);

  useEffect(() => {
    loadMusic();
  }, []);

  const loadMusic = async () => {
    try {
      const music = await api.getMusicLibrary();
      setMusicLibrary(music);
    } catch (err) {
      console.error('Failed to load music:', err);
    }
  };

  const validateVideo = (file: File): string | null => {
    const allowedTypes = ['video/mp4', 'video/webm', 'video/quicktime', 'video/x-matroska'];
    const isValidType = allowedTypes.some(type => file.type.includes(type));

    if (!isValidType) {
      return 'Only MP4, WebM, MOV, and MKV video files are allowed';
    }
    if (file.size > 100 * 1024 * 1024) {
      return 'File size must be less than 100MB';
    }
    return null;
  };

  const getVideoDuration = (file: File): Promise<number> => {
    return new Promise((resolve, reject) => {
      const video = document.createElement('video');
      video.preload = 'metadata';
      video.onloadedmetadata = () => {
        window.URL.revokeObjectURL(video.src);
        resolve(video.duration);
      };
      video.onerror = reject;
      video.src = URL.createObjectURL(file);
    });
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (!selectedFile) return;

    const validationError = validateVideo(selectedFile);
    if (validationError) {
      setError(validationError);
      return;
    }

    try {
      const duration = await getVideoDuration(selectedFile);
      if (duration < 1 || duration > 30) {
        setError('Video must be between 1 and 30 seconds');
        return;
      }
      setFile(selectedFile);
      setError('');
    } catch (err) {
      setError('Failed to read video file');
    }
  };

  const handleCameraRecording = (blob: Blob) => {
    const file = new File([blob], `recording-${Date.now()}.webm`, { type: 'video/webm' });
    setFile(file);
    setShowCamera(false);
    setError('');
  };

  const handleSubmit = async (e: React.FormEvent) => {
  e.preventDefault();
  if (!file) return;

  setLoading(true);
  setUploadProgress(0);
  setError('');

  try {
    const { data: user } = await supabase.auth.getUser();
    if (!user.user) throw new Error('Not authenticated');

    const duration = await getVideoDuration(file);
    const fileExt = file.name.split('.').pop();
    const fileName = `${user.user.id}/${Date.now()}.${fileExt}`;

    const { error: uploadError } = await supabase.storage
      .from('videos')
      .upload(fileName, file, {
        onUploadProgress: (progress) => {
          setUploadProgress((progress.loaded / progress.total) * 100);
        },
      });

    if (uploadError) throw uploadError;

    const { data: { publicUrl } } = supabase.storage
      .from('videos')
      .getPublicUrl(fileName);

    // 🚨 This calls your api.uploadVideo with the 1-per-day limit
    await api.uploadVideo({
      title: caption,
      url: publicUrl,
      is_private: isPrivate,
    });

    setSuccess(true);
    setTimeout(() => {
      setFile(null);
      setCaption('');
      setSelectedMusic('');
      setIsPrivate(false);
      setSuccess(false);
      setUploadProgress(0);
    }, 3000);

  } catch (err: any) {
    setError(err.message || 'Failed to upload video');
  } finally {
    setLoading(false);
  }
};


  if (showCamera) {
    return (
      <CameraRecorder
        onRecordingComplete={handleCameraRecording}
        onClose={() => setShowCamera(false)}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 p-4 md:p-8">
      <div className="max-w-2xl mx-auto">
        <div className="bg-slate-800/50 backdrop-blur-lg rounded-2xl shadow-2xl border border-slate-700 p-6 md:p-8">
          <h1 className="text-3xl font-bold text-white mb-2">Upload Video</h1>
          <p className="text-slate-400 mb-8">Share your creativity with the world</p>

          {success ? (
            <div className="text-center py-12">
              <div className="w-20 h-20 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Check className="text-green-500" size={40} />
              </div>
              <p className="text-white font-semibold text-xl mb-2">Video Uploaded!</p>
              <p className="text-slate-400">Your video is now live on Nagris</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Video Source
                </label>
                <div className="flex gap-4 mb-4">
                  <button
                    type="button"
                    onClick={() => setShowCamera(true)}
                    className="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-gradient-to-r from-cyan-500 to-orange-500 text-white rounded-lg hover:from-cyan-600 hover:to-orange-600 transition-all font-medium"
                  >
                    <Camera size={20} />
                    Record Video
                  </button>
                </div>
                <div className="relative text-center mb-2">
                  <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-slate-600"></div>
                  </div>
                  <div className="relative flex justify-center text-sm">
                    <span className="px-2 bg-slate-800 text-slate-400">or upload a file</span>
                  </div>
                </div>
                <div className="relative">
                  <input
                    type="file"
                    accept="video/mp4,video/webm,video/quicktime,video/x-matroska"
                    onChange={handleFileChange}
                    className="hidden"
                    id="video-upload"
                  />
                  <label
                    htmlFor="video-upload"
                    className="flex flex-col items-center justify-center w-full h-48 border-2 border-dashed border-slate-600 rounded-lg cursor-pointer hover:border-cyan-500 transition-colors bg-slate-700/30"
                  >
                    {file ? (
                      <div className="text-center">
                        <video
                          src={URL.createObjectURL(file)}
                          className="max-h-32 mx-auto mb-2 rounded"
                        />
                        <p className="text-white font-medium">{file.name}</p>
                        <p className="text-slate-400 text-sm">
                          {(file.size / (1024 * 1024)).toFixed(2)} MB
                        </p>
                      </div>
                    ) : (
                      <>
                        <UploadIcon className="text-slate-400 mb-3" size={48} />
                        <p className="text-white font-medium mb-1">Click to upload video</p>
                        <p className="text-slate-400 text-sm">MP4, WebM, MOV, max 100MB, 1-30 seconds</p>
                      </>
                    )}
                  </label>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Caption
                </label>
                <textarea
                  value={caption}
                  onChange={(e) => setCaption(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-700/50 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-cyan-500 resize-none"
                  rows={3}
                  placeholder="Write a caption for your video..."
                  maxLength={100}
                />
                <p className="text-xs text-slate-500 mt-1">{caption.length}/100</p>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  <Music size={16} className="inline mr-2" />
                  Background Music
                </label>
                <select
                  value={selectedMusic}
                  onChange={(e) => setSelectedMusic(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-700/50 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
                >
                  <option value="">No music</option>
                  {musicLibrary.map((music) => (
                    <option key={music.id} value={music.id}>
                      {music.title} - {music.artist}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-3">
                  Privacy
                </label>
                <div className="flex gap-4">
                  <button
                    type="button"
                    onClick={() => setIsPrivate(false)}
                    className={`flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-lg border-2 transition-colors ${
                      !isPrivate
                        ? 'border-cyan-500 bg-cyan-500/20 text-cyan-400'
                        : 'border-slate-600 bg-slate-700/30 text-slate-300'
                    }`}
                  >
                    <Globe size={20} />
                    <span>Public</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsPrivate(true)}
                    className={`flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-lg border-2 transition-colors ${
                      isPrivate
                        ? 'border-cyan-500 bg-cyan-500/20 text-cyan-400'
                        : 'border-slate-600 bg-slate-700/30 text-slate-300'
                    }`}
                  >
                    <Lock size={20} />
                    <span>Private</span>
                  </button>
                </div>
              </div>

              {error && (
                <div className="bg-red-500/10 border border-red-500/50 text-red-400 px-4 py-3 rounded-lg text-sm">
                  {error}
                </div>
              )}

              {loading && (
                <div>
                  <div className="bg-slate-700 rounded-full h-2 overflow-hidden">
                    <div
                      className="bg-gradient-to-r from-cyan-500 to-orange-500 h-full transition-all duration-300"
                      style={{ width: `${uploadProgress}%` }}
                    />
                  </div>
                  <p className="text-slate-400 text-sm text-center mt-2">
                    Uploading... {Math.round(uploadProgress)}%
                  </p>
                </div>
              )}

              <button
                type="submit"
                disabled={!file || loading}
                className="w-full py-4 bg-gradient-to-r from-cyan-500 to-orange-500 text-white font-semibold rounded-lg hover:from-cyan-600 hover:to-orange-600 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? 'Uploading...' : 'Upload Video'}
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
