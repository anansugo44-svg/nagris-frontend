import { useState } from "react";
import { Video } from "lucide-react";
import { useAuth } from "../lib/authContext";
import type { User } from '../lib/types';

interface AuthPageProps {
  onAuthSuccess: () => void;
}

export default function AuthPage({ onAuthSuccess }: AuthPageProps) {
  const { login, signup } = useAuth();

  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState("");
  const [username, setUsername] = useState("");
  const [country, setCountry] = useState("KE");
  const [birthday, setBirthday] = useState({ day: "", month: "", year: "" });
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const isOldEnough = () => {
    if (!birthday.day || !birthday.month || !birthday.year) return false;
    const birthDate = new Date(`${birthday.year}-${birthday.month}-${birthday.day}`);
    const age = new Date(Date.now() - birthDate.getTime()).getUTCFullYear() - 1970;
    return age >= 13;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      if (isLogin) {
        await login(email, password);
        onAuthSuccess();
      } else {
        if (!isOldEnough()) {
          setError("You must be at least 13 years old to sign up.");
          return;
        }
        await signup(email, password, username);
        onAuthSuccess();
      }
    } catch (err: any) {
      setError(err.message || "Authentication failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 flex items-center justify-center p-4">
      <div className="bg-slate-800 p-8 rounded-2xl border border-slate-700 max-w-md w-full">
        <div className="flex justify-center mb-6">
          <div className="bg-gradient-to-r from-cyan-500 to-orange-500 p-3 rounded-2xl">
            <Video className="w-10 h-10 text-white" />
          </div>
        </div>
        <h1 className="text-3xl text-center text-white mb-4">
          {isLogin ? "Welcome Back" : "Join Nagris"}
        </h1>

        <form onSubmit={handleSubmit} className="space-y-4">
          {!isLogin && (
            <>
              <input
                type="text"
                placeholder="Username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full p-3 bg-slate-800 border border-slate-700 text-white rounded-lg"
                required
              />

              {/* Birthday + Country */}
              <div className="grid grid-cols-3 gap-2">
                <select
                  value={birthday.month}
                  onChange={(e) => setBirthday({ ...birthday, month: e.target.value })}
                  className="p-2 bg-slate-800 border border-slate-700 text-white rounded-lg"
                >
                  <option value="">Month</option>
                  {[...Array(12)].map((_, i) => (
                    <option key={i + 1} value={String(i + 1).padStart(2, "0")}>
                      {new Date(2000, i).toLocaleString("default", { month: "long" })}
                    </option>
                  ))}
                </select>
                <select
                  value={birthday.day}
                  onChange={(e) => setBirthday({ ...birthday, day: e.target.value })}
                  className="p-2 bg-slate-800 border border-slate-700 text-white rounded-lg"
                >
                  <option value="">Day</option>
                  {[...Array(31)].map((_, i) => (
                    <option key={i + 1} value={String(i + 1).padStart(2, "0")}>
                      {i + 1}
                    </option>
                  ))}
                </select>
                <select
                  value={birthday.year}
                  onChange={(e) => setBirthday({ ...birthday, year: e.target.value })}
                  className="p-2 bg-slate-800 border border-slate-700 text-white rounded-lg"
                >
                  <option value="">Year</option>
                  {Array.from({ length: 100 }, (_, i) => new Date().getFullYear() - i).map(
                    (y) => (
                      <option key={y} value={y}>
                        {y}
                      </option>
                    )
                  )}
                </select>
              </div>

              <select
                value={country}
                onChange={(e) => setCountry(e.target.value)}
                className="w-full p-3 bg-slate-800 border border-slate-700 text-white rounded-lg"
              >
                <option value="KE">Kenya</option>
                <option value="SO">Somalia</option>
                <option value="US">United States</option>
                <option value="NG">Nigeria</option>
              </select>
            </>
          )}

          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full p-3 bg-slate-800 border border-slate-700 text-white rounded-lg"
            required
          />

          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full p-3 bg-slate-800 border border-slate-700 text-white rounded-lg"
            required
          />

          {error && <p className="text-red-400 text-sm">{error}</p>}

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 bg-gradient-to-r from-cyan-500 to-orange-500 text-white rounded-lg"
          >
            {loading ? "Please wait…" : isLogin ? "Login" : "Sign Up"}
          </button>
        </form>

        <div className="mt-6 text-center">
          <button
            onClick={() => setIsLogin(!isLogin)}
            className="text-cyan-400 hover:text-cyan-300 text-sm"
          >
            {isLogin
              ? "Don't have an account? Sign up"
              : "Already have an account? Log in"}
          </button>
        </div>
      </div>
    </div>
  );
}
