import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Clock, Shield, Bell, Eye, MessageCircle, Users, Download,
  LogOut, ChevronRight, Trash2, Bookmark, UserCircle2, ArrowLeft, ShoppingBag, BadgeCheck
} from 'lucide-react';
import type { User } from '../lib/types';
import { auth } from '../lib/auth';
import { api } from '../lib/api';
import { getUserVerification } from '../lib/verification';
import VerificationModal from './VerificationModal';

interface UserSettings {
  privacy_settings: {
    profile_visibility: string;
    who_can_comment: string;
    who_can_duet: string;
    who_can_message: string;
  };
  notification_settings: {
    likes: boolean;
    comments: boolean;
    new_followers: boolean;
    mentions: boolean;
    live_notifications: boolean;
  };
  theme_preference: string;
  show_activity_status: boolean;
  allow_mentions: boolean;
  allow_duets: boolean;
  allow_downloads: boolean;
}

export default function SettingsPage() {
  const navigate = useNavigate();
  const [settings, setSettings] = useState<UserSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState<User | null>(null);
  const [verification, setVerification] = useState<any>(null);
  const [showVerificationModal, setShowVerificationModal] = useState(false);

  useEffect(() => {
    loadUser();
    loadSettings();
    loadVerification();
  }, []);

  const loadUser = async () => {
    try {
      const currentUser = await auth.getCurrentUser(); // ✅ custom auth
      if (!currentUser) return;

      const profile = await api.getUserProfile(currentUser.id); // ✅ API call
      setUser(profile);
    } catch (err) {
      console.error('Failed to load user:', err);
    }
  };

  const loadVerification = async () => {
    try {
      const currentUser = await auth.getCurrentUser();
      if (!currentUser) return;

      const verificationData = await getUserVerification(currentUser.id);
      setVerification(verificationData);
    } catch (err) {
      console.error('Failed to load verification:', err);
    }
  };

  const loadSettings = async () => {
    try {
      const currentUser = await auth.getCurrentUser();
      if (!currentUser) return;

      const userSettings = await api.getUserSettings(currentUser.id);
      setSettings(userSettings);
    } catch (err) {
      console.error('Failed to load settings:', err);
    } finally {
      setLoading(false);
    }
  };

  const updateSettings = async (updates: Partial<UserSettings>) => {
    try {
      const currentUser = await auth.getCurrentUser();
      if (!currentUser) return;

      const newSettings = { ...settings, ...updates };
      setSettings(newSettings);

      await api.updateUserSettings(currentUser.id, newSettings);
    } catch (err) {
      console.error('Failed to update settings:', err);
    }
  };

  const handleLogout = async () => {
    if (confirm('Are you sure you want to log out?')) {
      await auth.signOut();
      window.location.href = '/';
    }
  };

  const handleSwitchAccount = () => {
    if (confirm('Switch to another account? You will be logged out.')) {
      handleLogout();
    }
  };

  const handleClearHistory = async () => {
    if (confirm('Are you sure you want to clear your watch history? This cannot be undone.')) {
      try {
        const currentUser = await auth.getCurrentUser();
        if (!currentUser) return;

        await api.clearWatchHistory(currentUser.id);
        alert('Watch history cleared successfully');
      } catch (err) {
        console.error('Failed to clear history:', err);
        alert('Failed to clear watch history');
      }
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 flex items-center justify-center">
        <p className="text-white">Loading settings...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 pb-20">
      <div className="max-w-2xl mx-auto">
        <div className="sticky top-0 bg-slate-900/80 backdrop-blur-lg border-b border-slate-700 px-4 py-4 flex items-center gap-4 z-10">
          <button
            onClick={() => navigate('/profile')}
            className="text-white hover:bg-slate-700/50 p-2 rounded-lg transition-colors"
          >
            <ArrowLeft size={24} />
          </button>
          <h1 className="text-xl font-bold text-white">Settings and privacy</h1>
        </div>

        <div className="px-4 py-6 space-y-2">
          <div className="bg-slate-800/50 backdrop-blur-lg rounded-2xl border border-slate-700 overflow-hidden">
            <button
              onClick={() => navigate('/profile')}
              className="w-full flex items-center gap-4 p-4 hover:bg-slate-700/30 transition-colors"
            >
              <img
                src={user?.avatar_url || 'https://via.placeholder.com/48'}
                alt={user?.username}
                className="w-12 h-12 rounded-full border-2 border-cyan-500"
              />
              <div className="flex-1 text-left">
                <p className="text-white font-medium">{user?.username || 'User'}</p>
                <p className="text-slate-400 text-sm">View profile</p>
              </div>
              <ChevronRight size={20} className="text-slate-400" />
            </button>
          </div>

          <div className="text-slate-400 text-sm font-medium px-2 mt-6 mb-2">Monetization</div>

          <div className="bg-slate-800/50 backdrop-blur-lg rounded-2xl border border-slate-700 overflow-hidden">
            <button
              onClick={() => setShowVerificationModal(true)}
              className="w-full flex items-center justify-between p-4 hover:bg-slate-700/30 transition-colors border-b border-slate-700"
            >
              <div className="flex items-center gap-3">
                <BadgeCheck size={20} className={verification?.is_verified ? "text-green-400" : "text-slate-400"} />
                <div className="text-left">
                  <span className="text-white font-medium block">Account Verification</span>
                  {verification?.is_verified && (
                    <span className="text-green-400 text-xs">Verified</span>
                  )}
                  {!verification?.is_verified && (
                    <span className="text-yellow-400 text-xs">Required for monetization</span>
                  )}
                </div>
              </div>
              <ChevronRight size={20} className="text-slate-400" />
            </button>

            <button
              onClick={() => navigate('/shop')}
              className="w-full flex items-center justify-between p-4 hover:bg-slate-700/30 transition-colors"
            >
              <div className="flex items-center gap-3">
                <ShoppingBag size={20} className="text-slate-400" />
                <span className="text-white font-medium">Shop</span>
              </div>
              <ChevronRight size={20} className="text-slate-400" />
            </button>
          </div>

          <div className="text-slate-400 text-sm font-medium px-2 mt-6 mb-2">Account</div>

          <div className="bg-slate-800/50 backdrop-blur-lg rounded-2xl border border-slate-700 overflow-hidden">
            <button
              onClick={handleSwitchAccount}
              className="w-full flex items-center justify-between p-4 hover:bg-slate-700/30 transition-colors border-b border-slate-700"
            >
              <div className="flex items-center gap-3">
                <UserCircle2 size={20} className="text-slate-400" />
                <span className="text-white font-medium">Switch account</span>
              </div>
              <ChevronRight size={20} className="text-slate-400" />
            </button>

            <button
              onClick={() => navigate('/profile')}
              className="w-full flex items-center justify-between p-4 hover:bg-slate-700/30 transition-colors"
            >
              <div className="flex items-center gap-3">
                <Clock size={20} className="text-slate-400" />
                <span className="text-white font-medium">Watch history</span>
              </div>
              <ChevronRight size={20} className="text-slate-400" />
            </button>
          </div>

          <div className="bg-slate-800/50 backdrop-blur-lg rounded-2xl border border-slate-700 overflow-hidden">
            <button
              onClick={handleClearHistory}
              className="w-full flex items-center justify-between p-4 hover:bg-slate-700/30 transition-colors"
            >
              <div className="flex items-center gap-3">
                <Trash2 size={20} className="text-red-400" />
                <span className="text-white font-medium">Clear watch history</span>
              </div>
            </button>
          </div>

          <div className="text-slate-400 text-sm font-medium px-2 mt-6 mb-2">Content & Activity</div>

          <div className="bg-slate-800/50 backdrop-blur-lg rounded-2xl border border-slate-700 overflow-hidden">
            <button
              onClick={() => navigate('/profile')}
              className="w-full flex items-center justify-between p-4 hover:bg-slate-700/30 transition-colors"
            >
              <div className="flex items-center gap-3">
                <Bookmark size={20} className="text-slate-400" />
                <span className="text-white font-medium">Saved videos</span>
              </div>
              <ChevronRight size={20} className="text-slate-400" />
            </button>
          </div>

          <div className="text-slate-400 text-sm font-medium px-2 mt-6 mb-2">Privacy & Safety</div>

          <div className="bg-slate-800/50 backdrop-blur-lg rounded-2xl border border-slate-700 overflow-hidden">
            <div className="p-4 space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Eye size={18} className="text-slate-400" />
                  <span className="text-white">Show Activity Status</span>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings?.show_activity_status || false}
                    onChange={(e) => updateSettings({ show_activity_status: e.target.checked })}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-600 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-gradient-to-r peer-checked:from-cyan-500 peer-checked:to-orange-500"></div>
                </label>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <MessageCircle size={18} className="text-slate-400" />
                  <span className="text-white">Allow Mentions</span>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings?.allow_mentions || false}
                    onChange={(e) => updateSettings({ allow_mentions: e.target.checked })}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-600 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-gradient-to-r peer-checked:from-cyan-500 peer-checked:to-orange-500"></div>
                </label>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Users size={18} className="text-slate-400" />
                  <span className="text-white">Allow Duets</span>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings?.allow_duets || false}
                    onChange={(e) => updateSettings({ allow_duets: e.target.checked })}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-600 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-gradient-to-r peer-checked:from-cyan-500 peer-checked:to-orange-500"></div>
                </label>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Download size={18} className="text-slate-400" />
                  <span className="text-white">Allow Downloads</span>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings?.allow_downloads || false}
                    onChange={(e) => updateSettings({ allow_downloads: e.target.checked })}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-600 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-gradient-to-r peer-checked:from-cyan-500 peer-checked:to-orange-500"></div>
                </label>
              </div>
            </div>
          </div>

          <div className="text-slate-400 text-sm font-medium px-2 mt-6 mb-2">Notifications</div>

          <div className="bg-slate-800/50 backdrop-blur-lg rounded-2xl border border-slate-700 overflow-hidden">
            <div className="p-4 space-y-4">
              {settings?.notification_settings && Object.entries(settings.notification_settings).map(([key, value]) => (
                <div key={key} className="flex items-center justify-between">
                  <span className="text-white capitalize">{key.replace('_', ' ')}</span>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={value}
                      onChange={(e) => updateSettings({
                        notification_settings: {
                          ...settings.notification_settings,
                          [key]: e.target.checked
                        }
                      })}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-slate-600 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-gradient-to-r peer-checked:from-cyan-500 peer-checked:to-orange-500"></div>
                  </label>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-slate-800/50 backdrop-blur-lg rounded-2xl border border-slate-700 overflow-hidden mt-6">
            <button
              onClick={handleLogout}
              className="w-full flex items-center justify-between p-4 hover:bg-red-500/10 transition-colors group"
            >
              <div className="flex items-center gap-3">
                <LogOut size={20} className="text-red-400" />
                <span className="text-red-400 font-medium">Log out</span>
              </div>
            </button>
          </div>
        </div>
      </div>

      {showVerificationModal && (
        <VerificationModal
          onClose={() => setShowVerificationModal(false)}
          onSuccess={() => {
            loadVerification();
          }}
        />
      )}
    </div>
  );
}
