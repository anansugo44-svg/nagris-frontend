import { useState, useEffect, useRef } from 'react';
import { X, Send, Gift as GiftIcon, Gamepad2, Users, Heart, MoreVertical } from 'lucide-react';
import { liveApi, type LiveStream, type ChatMessage } from '../lib/liveApi';
import { api } from '../lib/api';
import { useAuth } from '../lib/newAuthContext'; // ✅ custom auth
import type { User, Gift } from '../lib/types';
import LiveGamePanel from './LiveGamePanel';

interface LiveStreamViewerProps {
  streamId: string;
  onClose: () => void;
}

export default function LiveStreamViewer({ streamId, onClose }: LiveStreamViewerProps) {
  const { user } = useAuth(); // ✅ current user
  const [stream, setStream] = useState<LiveStream | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [gifts, setGifts] = useState<Gift[]>([]);
  const [showGifts, setShowGifts] = useState(false);
  const [showGames, setShowGames] = useState(false);
  const [isHost, setIsHost] = useState(false);
  const [loading, setLoading] = useState(true);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    loadStream();
    loadGifts();
    loadMessages();
    joinStream();

    const chatSubscription = liveApi.subscribeToChatMessages(streamId, (message) => {
      setMessages(prev => [...prev, message]);
    });

    const giftSubscription = liveApi.subscribeToGifts(streamId, (gift) => {
      console.log('Gift received:', gift);
    });

    return () => {
      leaveStream();
      chatSubscription.unsubscribe();
      giftSubscription.unsubscribe();
    };
  }, [streamId]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const loadStream = async () => {
    try {
      const data = await liveApi.getLiveStream(streamId);
      setStream(data);

      if (user && data) {
        setIsHost(user.id === data.user_id);
      }
    } catch (err) {
      console.error('Failed to load stream:', err);
    } finally {
      setLoading(false);
    }
  };

  const loadGifts = async () => {
    try {
      const data = await api.getGifts();
      setGifts(data);
    } catch (err) {
      console.error('Failed to load gifts:', err);
    }
  };

  const loadMessages = async () => {
    try {
      const data = await liveApi.getChatMessages(streamId);
      setMessages(data);
    } catch (err) {
      console.error('Failed to load messages:', err);
    }
  };

  const joinStream = async () => {
    try {
      await liveApi.joinLive(streamId);
    } catch (err) {
      console.error('Failed to join stream:', err);
    }
  };

  const leaveStream = async () => {
    try {
      await liveApi.leaveLive(streamId);
    } catch (err) {
      console.error('Failed to leave stream:', err);
    }
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim()) return;

    try {
      await liveApi.sendChatMessage(streamId, newMessage);
      setNewMessage('');
    } catch (err) {
      console.error('Failed to send message:', err);
    }
  };

  const handleSendGift = async (giftId: string) => {
    try {
      await liveApi.sendGift(streamId, giftId);
      setShowGifts(false);
      alert('Gift sent successfully!');
    } catch (err: any) {
      alert(err.message || 'Failed to send gift');
    }
  };

  const handleEndStream = async () => {
    if (!confirm('Are you sure you want to end this live stream?')) return;

    try {
      await liveApi.endLive(streamId);
      onClose();
    } catch (err) {
      console.error('Failed to end stream:', err);
    }
  };

  if (loading) {
    return (
      <div className="fixed inset-0 bg-black flex items-center justify-center z-50">
        <div className="text-white text-center">
          <div className="w-12 h-12 border-4 border-white border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p>Loading stream...</p>
        </div>
      </div>
    );
  }

  if (!stream) {
    return (
      <div className="fixed inset-0 bg-black flex items-center justify-center z-50">
        <div className="text-white text-center">
          <p className="mb-4">Stream not found</p>
          <button
            onClick={onClose}
            className="px-6 py-2 bg-white text-black rounded-lg"
          >
            Go Back
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black z-50 flex flex-col md:flex-row">
      <div className="flex-1 relative">
        <div className="absolute inset-0 flex items-center justify-center bg-slate-900">
          <div className="text-center text-white">
            <div className="w-32 h-32 bg-gradient-to-br from-red-500 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <Users size={64} />
            </div>
            <p className="text-lg font-semibold mb-2">Agora WebRTC Integration</p>
            <p className="text-sm text-slate-400">Video stream will appear here</p>
            <div className="mt-4 px-4 py-2 bg-white/10 rounded-lg inline-block">
              <p className="text-xs">Channel: {stream.agora_channel_id}</p>
            </div>
          </div>
        </div>

        <button
          onClick={onClose}
          className="absolute top-4 left-4 z-10 p-2 bg-black/50 backdrop-blur-sm rounded-full text-white hover:bg-black/70 transition-colors"
        >
          <X size={24} />
        </button>

        <div className="absolute top-4 left-1/2 -translate-x-1/2 z-10 bg-red-500 text-white px-4 py-2 rounded-full text-sm font-bold flex items-center gap-2 animate-pulse">
          <div className="w-2 h-2 bg-white rounded-full"></div>
          LIVE
        </div>

        <div className="absolute top-4 right-4 z-10 flex gap-2">
          <div className="bg-black/50 backdrop-blur-sm text-white px-3 py-2 rounded-full text-sm font-semibold flex items-center gap-1">
            <Users size={16} />
            {stream.viewer_count}
          </div>
          {isHost && (
            <>
              <button
                onClick={() => setShowGames(!showGames)}
                className="p-2 bg-black/50 backdrop-blur-sm rounded-full text-white hover:bg-black/70 transition-colors"
              >
                <Gamepad2 size={20} />
              </button>
              <button
                onClick={handleEndStream}
                className="px-4 py-2 bg-red-500 backdrop-blur-sm rounded-full text-white hover:bg-red-600 transition-colors font-semibold text-sm"
              >
                End Stream
              </button>
            </>
          )}
        </div>

        <div className="absolute bottom-20 left-4 right-4 md:right-auto md:max-w-sm z-10">
          <div className="bg-gradient-to-t from-black/80 to-transparent p-4">
            <div className="flex items-center gap-2 mb-2">
              <img
                src={stream.user?.avatar_url || 'https://via.placeholder.com/40'}
                alt={stream.user?.username}
                className="w-10 h-10 rounded-full border-2 border-white"
              />
              <div>
                <p className="text-white font-semibold">
                  {stream.user?.username}
                  {stream.user?.is_verified && <span className="ml-1">✓</span>}
                </p>
                <p className="text-white/80 text-sm">{stream.title}</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="w-full md:w-96 bg-slate-900 flex flex-col h-1/3 md:h-full">
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {messages.map((msg) => (
            <div key={msg.id} className="flex items-start gap-2">
              <img
                src={msg.user?.avatar_url || 'https://via.placeholder.com/32'}
                alt={msg.user?.username}
                className="w-8 h-8 rounded-full flex-shrink-0"
              />
              <div className="flex-1 min-w-0">
                <p className="text-xs">
                  <span className="text-white font-semibold">{msg.user?.username}</span>
                  {msg.user?.is_verified && <span className="text-cyan-400 ml-1">✓</span>}
                </p>
                <p className="text-sm text-white/90 break-words">{msg.message}</p>
              </div>
            </div>
          ))}
          <div ref={chatEndRef} />
        </div>

        <div className="p-4 border-t border-slate-700">
          <div className="flex gap-2 mb-3">
            <button
              onClick={() => setShowGifts(!showGifts)}
              className="p-2 bg-slate-800 hover:bg-slate-700 rounded-lg text-white transition-colors"
            >
              <GiftIcon size={20} />
            </button>
          </div>

          {showGifts && (
            <div className="mb-3 p-3 bg-slate-800 rounded-lg max-h-40 overflow-y-auto">
              <p className="text-white text-sm font-semibold mb-2">Send a Gift</p>
              <div className="grid grid-cols-4 gap-2">
                {gifts.map((gift) => (
                  <button
                    key={gift.id}
                    onClick={() => handleSendGift(gift.id)}
                    className="flex flex-col items-center p-2 bg-slate-700 hover:bg-slate-600 rounded-lg transition-colors"
                  >
                    <span className="text-2xl mb-1">{gift.icon}</span>
                    <span className="text-xs text-white font-semibold">{gift.coin_cost}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          <form onSubmit={handleSendMessage} className="flex gap-2">
            <input
              type="text"
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              placeholder="Say something..."
              className="flex-1 px-4 py-2 bg-slate-800 text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500"
              maxLength={200}
            />
            <button
              type="submit"
              disabled={!newMessage.trim()}
              className="p-2 bg-cyan-500 hover:bg-cyan-600 rounded-lg text-white transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Send size={20} />
            </button>
          </form>
        </div>
      </div>

      {showGames && isHost && (
        <LiveGamePanel
          streamId={streamId}
          onClose={() => setShowGames(false)}
        />
      )}
    </div>
  );
}
