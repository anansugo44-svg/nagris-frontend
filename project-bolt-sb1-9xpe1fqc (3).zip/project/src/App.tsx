import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useEffect } from 'react';
import { AuthProvider, useAuth } from './lib/newAuthContext';
import HomePage from './components/HomePage';
import LivePage from './components/LivePage';
import UploadPage from './components/UploadPage';
import ProfilePage from './components/ProfilePage';
import NotificationsPage from './components/NotificationsPage';
import WalletPage from './components/WalletPage';
import AdminPage from './components/AdminPage';
import SettingsPage from './components/SettingsPage';
import ShopPage from './components/ShopPage';
import BottomNav from './components/BottomNav';
import NewAuthPage from './components/NewAuthPage';
import ProtectedRoute from './components/ProtectedRoute';

// 🔹 Wrapper to handle login redirect before rendering the app
function AppRoutes() {
  const { user, loading } = useAuth();

  if (loading) {
    return <div className="text-white text-center p-10">Loading...</div>;
  }

  if (!user) {
    return <NewAuthPage onAuthSuccess={() => {}} />;
  }

  return (
    <div className="min-h-screen bg-slate-900">
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/live" element={<LivePage />} />

        <Route
          path="/upload"
          element={
            <ProtectedRoute>
              <UploadPage />
            </ProtectedRoute>
          }
        />

        <Route path="/notifications" element={<NotificationsPage />} />

        <Route
          path="/wallet"
          element={
            <ProtectedRoute>
              <WalletPage />
            </ProtectedRoute>
          }
        />

        <Route
          path="/profile"
          element={
            <ProtectedRoute>
              <ProfilePage />
            </ProtectedRoute>
          }
        />

        <Route path="/profile/:userId" element={<ProfilePage />} />
        <Route path="/settings" element={<SettingsPage />} />
        <Route path="/shop" element={<ShopPage />} />
        <Route path="/admin" element={<AdminPage />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>

      <BottomNav />
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <Router>
        <AppRoutes />
      </Router>
    </AuthProvider>
  );
}

export default App;