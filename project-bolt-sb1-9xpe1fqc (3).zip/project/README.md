# Nagris - TikTok-like Video Sharing Platform

A complete, production-ready video sharing platform similar to TikTok, built with React, TypeScript, Tailwind CSS, and Supabase.

## Features

### 🎥 Core Video Features
- **Vertical infinite-scroll feed** with autoplay and swipe navigation
- **Video upload** with validation (15-30s, MP4, max 50MB)
- **Likes, comments, shares, and bookmarks** on videos
- **Royalty-free music library** for background audio
- **Privacy controls** (public/private videos)
- **Watch history** tracking

### 👤 User Features
- **JWT authentication** (signup/login)
- **User profiles** with avatar, bio, followers/following counts
- **Follow/unfollow** functionality
- **Multiple profile tabs**: Videos, Liked, Private, Saved
- **Search** for users and videos
- **Block users** for safety

### 💰 Monetization System
- **Wallet with USD balances**:
  - Views Balance (earnings from video views)
  - Gifts Balance (earnings from live stream gifts)
- **Country-specific payout rules**:
  - Kenya & Somalia: View earnings active (requires 1M views, 20k likes, 10k followers)
  - Other countries: View earnings coming soon, gifts active
- **Withdrawal system**:
  - Minimum: $10 USD
  - Views payouts: Monthly (20th-25th)
  - Gifts payouts: Weekly (Fridays)
  - Payment methods: M-Pesa, EVC/Zaad, PayPal, Card
- **KYC verification** for high earners

### 🎬 Live Streaming
- **Go Live** (requires 500+ followers)
- **Real-time chat** in live rooms
- **Send gifts** (40% creator / 60% platform split)
- **Mini-games** (polls, trivia, spin wheel) - scaffolding ready
- **Viewer count** and gift tracking

### 🛡️ Safety & Moderation
- **Report system** for videos and users
- **Content moderation queue** with admin dashboard
- **Audio fingerprinting** check for copyright (scaffolding)
- **NSFW/violence detection** (scaffolding)
- **Fraud detection** scoring system
- **Audit logs** for all critical actions

### 📱 User Experience
- **Dark navy + cyan + orange gradient theme**
- **Mobile-first responsive design**
- **Bottom navigation** with 7 main sections
- **Notifications/Inbox** for all activities
- **Real-time updates** for likes, comments, follows

### 🔧 Admin Dashboard
- **Withdrawal request management** (approve/deny)
- **Reports moderation queue**
- **User and payout oversight**

## Tech Stack

- **Frontend**: React 18 + TypeScript + Vite
- **Styling**: Tailwind CSS
- **Database**: Supabase (PostgreSQL)
- **Authentication**: Supabase Auth (JWT)
- **Storage**: Supabase Storage
- **Icons**: Lucide React
- **Routing**: React Router v6

## Getting Started

### Prerequisites

- Node.js 18+ installed
- A Supabase project (already configured in this instance)

### Installation

1. Install dependencies:
```bash
npm install
```

2. Environment variables are already configured in `.env`:
```
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
```

3. Run development server:
```bash
npm run dev
```

4. Build for production:
```bash
npm run build
```

## Database Schema

The application uses a comprehensive PostgreSQL schema with the following main tables:

- **users** - Extended user profiles with monetization data
- **videos** - Video content with metadata
- **comments** - Comments and replies
- **follows** - User relationships
- **likes, saves, watch_history** - User interactions
- **wallets** - User balances (views + gifts)
- **withdrawal_requests** - Payout requests
- **gifts** - Live stream gift transactions
- **live_rooms, live_chat, live_games** - Live streaming
- **notifications** - User notifications
- **reports** - Content moderation
- **music_library** - Licensed background music
- **blocks** - User blocking
- **audit_logs** - System audit trail

All tables have Row Level Security (RLS) enabled with appropriate policies.

## API Structure

The app uses Supabase client for all database operations. Key API modules:

- **lib/auth.ts** - Authentication functions
- **lib/api.ts** - All database queries (videos, users, comments, wallet, etc.)
- **lib/supabase.ts** - Supabase client and TypeScript types

## Pages & Routes

- `/` - Home feed (infinite scroll videos)
- `/search` - Search users and videos
- `/live` - Active live streams
- `/upload` - Upload new video
- `/notifications` - Notifications inbox
- `/wallet` - Wallet and withdrawal management
- `/profile` - Current user profile
- `/profile/:userId` - View other user profiles
- `/admin` - Admin dashboard (payouts & reports)

## Key Components

- **VideoPlayer** - Video playback with interactions
- **CommentsModal** - Comments and replies
- **ReportModal** - Report content
- **UploadPage** - Video upload with validation
- **WalletPage** - Monetization dashboard
- **AdminPage** - Moderation and payout management
- **BottomNav** - Main navigation

## Monetization Rules

### View Earnings
- **Somalia & Kenya**: Active with thresholds
  - Requires: 1M total views + 20k likes + 10k followers
  - Rate: $15 USD per 1M views
  - Payouts: Monthly (20th-25th)
- **Other countries**: Coming soon (displayed but locked)

### Gift Earnings
- **All countries**: Active
- **Split**: 40% creator, 60% platform
- **Payouts**: Weekly on Fridays
- **Minimum withdrawal**: $10 USD

## Security Features

1. **Authentication**: JWT-based via Supabase Auth
2. **RLS Policies**: All tables protected with row-level security
3. **Input Validation**: Client and server-side validation
4. **Content Moderation**: Auto-flagging + manual review
5. **Fraud Detection**: Score-based system
6. **KYC**: Required for high-value withdrawals
7. **Audit Logs**: Track all sensitive operations

## Production Notes

### Video Storage
- Currently configured to use Supabase Storage
- Videos stored in `videos` bucket with public read access
- Users can only manage their own videos

### Live Streaming
- Scaffolding ready for Agora SDK integration
- WebRTC connection handling prepared
- Gifts and chat infrastructure in place

### Payment Processing
- Withdrawal requests stored in database
- Admin approval required before processing
- Batch processing for efficiency
- Support for M-Pesa, EVC, Zaad, PayPal, Card

### Content Moderation
- Audio fingerprinting system ready (needs library integration)
- NSFW detection scaffolding (needs ML model)
- Manual review queue for flagged content
- Block and report features fully functional

## Development Scripts

```bash
npm run dev        # Start development server
npm run build      # Build for production
npm run preview    # Preview production build
npm run lint       # Lint code
npm run typecheck  # TypeScript type checking
```

## Future Enhancements

1. **Complete live streaming** with Agora SDK
2. **Audio fingerprinting** integration for copyright detection
3. **NSFW/violence ML models** for auto-moderation
4. **Push notifications** via FCM or similar
5. **Analytics dashboard** for creators
6. **Trending algorithm** and recommendation engine
7. **Direct messaging** between users
8. **Duets and Stitches** features
9. **Advanced video editing** tools
10. **Mobile apps** (React Native)

## License

This project is for demonstration purposes. All rights reserved.

## Support

For issues or questions, please check the code comments or reach out to the development team.

---

Built with ❤️ using React, TypeScript, Tailwind CSS, and Supabase.
